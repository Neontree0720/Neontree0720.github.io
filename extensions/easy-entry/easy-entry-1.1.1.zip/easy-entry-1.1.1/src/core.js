// 엔트리 페이지 안(MAIN 세계)에서 실행됩니다. window.Entry에 직접 접근할 수 있어요.
// 하는 일: 설정 받기, 엔트리가 준비될 때까지 기다리기, 엔트리 명령(블록 꺼내기 등)을 기능들에 알려 주기.
(() => {
  'use strict';

  if (window.__easyEntry) return; // 두 번 실행되지 않게

  const LOG_PREFIX = '[이지 엔트리]';

  // defaults.js와 같은 값이어야 합니다.
  const settings = {
    sceneStartPair: true,
    pairPosition: 'right',
    traceBackground: true,
    jointWarp: true
  };

  const features = [];

  function applySettings(raw) {
    let next;
    try {
      next = JSON.parse(raw);
    } catch (e) {
      return;
    }
    if (!next || typeof next !== 'object') return;
    // 아는 키만, 같은 타입일 때만 받아들입니다.
    Object.keys(settings).forEach((key) => {
      if (typeof next[key] === typeof settings[key]) settings[key] = next[key];
    });
  }

  window.addEventListener('easy-entry:settings', (e) => applySettings(e.detail));

  function getEntry() {
    const E = window.Entry;
    return E && typeof E === 'object' ? E : null;
  }

  // 지금 되돌리기/다시 실행 중이면 true. 이때 블록을 더 만들면 블록이 겹쳐 생깁니다.
  function isUndoRedoInProgress() {
    const E = getEntry();
    const sm = E && E.stateManager;
    if (!sm) return false;
    try {
      if (sm._isRedoing) return true;
      if (typeof sm.isRestoring === 'function' && sm.isRestoring()) return true;
    } catch (e) {
      return false;
    }
    return false;
  }

  function commandName(type) {
    const E = getEntry();
    try {
      if (typeof type === 'string') return type;
      if (E && E.STATIC && typeof E.STATIC.getCommandName === 'function') {
        return E.STATIC.getCommandName(type);
      }
    } catch (e) {
      // 무시
    }
    return null;
  }

  function onCommand(type, args) {
    const name = commandName(type);
    if (!name) return;
    const list = Array.isArray(args) ? args : [];
    features.forEach((feature) => {
      try {
        feature.onCommand(name, list);
      } catch (e) {
        console.warn(LOG_PREFIX, feature.id, '기능에서 오류가 났어요:', e);
      }
    });
  }

  // 엔트리 명령이 실행된 뒤마다 호출되는 이벤트(commander.doEvent)에 연결합니다.
  // 엔트리가 다시 만들어질 수도 있어서 주기적으로 확인하고 다시 연결합니다.
  let attachedEvent = null;
  let listener = null;

  function tryAttach() {
    const E = getEntry();
    const ev = E && E.commander && E.commander.doEvent;
    if (!ev || typeof ev.attach !== 'function') return;
    if (ev === attachedEvent) return;

    if (attachedEvent && listener && typeof attachedEvent.detach === 'function') {
      try {
        attachedEvent.detach(listener);
      } catch (e) {
        // 무시
      }
    }
    listener = ev.attach(null, onCommand);
    attachedEvent = ev;
    console.info(LOG_PREFIX, '엔트리에 연결했어요.');
  }

  window.__easyEntry = {
    settings,
    getEntry,
    isUndoRedoInProgress,
    log: (...a) => console.info(LOG_PREFIX, ...a),
    warn: (...a) => console.warn(LOG_PREFIX, ...a),
    registerFeature(feature) {
      if (feature && typeof feature.onCommand === 'function') features.push(feature);
    }
  };

  tryAttach();
  setInterval(tryAttach, 1000);
  window.dispatchEvent(new CustomEvent('easy-entry:request-settings'));
})();
