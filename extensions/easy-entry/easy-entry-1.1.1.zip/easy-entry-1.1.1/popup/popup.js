(() => {
  'use strict';

  const toggle = document.getElementById('sceneStartPair');
  const positionGroup = document.getElementById('pairPositionGroup');
  const radios = Array.from(document.querySelectorAll('input[name="pairPosition"]'));

  const traceToggle = document.getElementById('traceBackground');
  const jointToggle = document.getElementById('jointWarp');
  const darkToggle = document.getElementById('darkMode');
  const accentGroup = document.getElementById('accentGroup');
  const accentRadios = Array.from(document.querySelectorAll('input[name="accentColor"]'));
  const blueRadios = Array.from(document.querySelectorAll('input[name="blueColor"]'));

  function renderDark(on) {
    accentGroup.classList.toggle('is-disabled', !on);
  }

  function render(settings) {
    darkToggle.checked = !!settings.darkMode;
    renderDark(!!settings.darkMode);
    accentRadios.forEach((r) => {
      r.checked = r.value === settings.accentColor;
    });
    blueRadios.forEach((r) => {
      r.checked = r.value === settings.blueColor;
    });
    traceToggle.checked = !!settings.traceBackground;
    jointToggle.checked = !!settings.jointWarp;
    toggle.checked = !!settings.sceneStartPair;
    positionGroup.disabled = !settings.sceneStartPair;
    radios.forEach((r) => {
      r.checked = r.value === settings.pairPosition;
    });
  }

  function save(patch) {
    chrome.storage.sync.set(patch);
  }

  chrome.storage.sync.get(EASY_ENTRY_DEFAULTS, render);

  toggle.addEventListener('change', () => {
    positionGroup.disabled = !toggle.checked;
    save({ sceneStartPair: toggle.checked });
  });

  traceToggle.addEventListener('change', () => {
    save({ traceBackground: traceToggle.checked });
  });

  jointToggle.addEventListener('change', () => {
    save({ jointWarp: jointToggle.checked });
  });

  darkToggle.addEventListener('change', () => {
    renderDark(darkToggle.checked);
    save({ darkMode: darkToggle.checked });
  });

  accentRadios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ accentColor: r.value });
    });
  });

  blueRadios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ blueColor: r.value });
    });
  });

  radios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ pairPosition: r.value });
    });
  });
})();
