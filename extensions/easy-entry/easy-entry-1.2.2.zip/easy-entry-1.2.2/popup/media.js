// 배경음악 파일, 엔트리 이야기 배경 사진 고르기
(() => {
  'use strict';

  const MAX_MUSIC_MB = 40;
  const MAX_SIDE = 1920; // 배경 사진은 긴 쪽 1920px 까지 줄여서 저장해요.

  const $ = (id) => document.getElementById(id);

  function message(id, text, error) {
    const el = $(id);
    el.textContent = text || '';
    el.classList.toggle('error', !!error);
  }

  // ---------- 배경음악 ----------
  let previewUrl = null;

  async function renderBgm() {
    const { bgmName } = await chrome.storage.local.get({ bgmName: '' });
    $('bgmName').textContent = bgmName ? '♪ ' + bgmName : '음악을 아직 고르지 않았어요';
    $('bgmClear').hidden = !bgmName;
    const track = bgmName ? await EasyEntryMediaDB.get('bgm') : null;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = track && track.blob ? URL.createObjectURL(track.blob) : null;
    $('bgmPreview').hidden = !previewUrl;
    if (previewUrl) $('bgmPreview').src = previewUrl;
  }

  $('bgmFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (!/^audio\//.test(file.type) && !/\.mp3$/i.test(file.name)) {
      message('bgmMsg', '음악 파일(mp3)만 고를 수 있어요.', true);
      return;
    }
    if (file.size > MAX_MUSIC_MB * 1024 * 1024) {
      message('bgmMsg', `${MAX_MUSIC_MB}MB 보다 작은 파일을 골라 주세요.`, true);
      return;
    }
    message('bgmMsg', '저장하는 중...');
    try {
      await EasyEntryMediaDB.set('bgm', { name: file.name, blob: file });
      await chrome.storage.local.set({ bgmName: file.name, bgmId: Date.now() });
      message('bgmMsg', '저장했어요! 엔트리 페이지를 열면 나와요.');
      renderBgm();
    } catch (err) {
      message('bgmMsg', '저장하지 못했어요: ' + err.message, true);
    }
  });

  $('bgmClear').addEventListener('click', async () => {
    await EasyEntryMediaDB.remove('bgm');
    await chrome.storage.local.set({ bgmName: '', bgmId: Date.now() });
    message('bgmMsg', '음악을 지웠어요.');
    renderBgm();
  });

  // ---------- 엔트리 이야기 배경 ----------
  async function renderStory() {
    const { storyBgImage, storyBgName } = await chrome.storage.local.get({ storyBgImage: '', storyBgName: '' });
    $('storyName').textContent = storyBgImage ? storyBgName || '고른 사진' : '사진을 아직 고르지 않았어요';
    $('storyClear').hidden = !storyBgImage;
    $('storyPreview').hidden = !storyBgImage;
    if (storyBgImage) $('storyPreview').src = storyBgImage;
  }

  function shrink(file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
        const cv = document.createElement('canvas');
        cv.width = Math.round(img.naturalWidth * k);
        cv.height = Math.round(img.naturalHeight * k);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        resolve(cv.toDataURL('image/jpeg', 0.86));
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('사진을 열 수 없어요.'));
      };
      img.src = url;
    });
  }

  $('storyFile').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (!/^image\//.test(file.type)) {
      message('storyMsg', '사진 파일만 고를 수 있어요.', true);
      return;
    }
    message('storyMsg', '저장하는 중...');
    try {
      const data = await shrink(file);
      await chrome.storage.local.set({ storyBgImage: data, storyBgName: file.name });
      message('storyMsg', '저장했어요! 엔트리 이야기에서 바로 보여요.');
      renderStory();
    } catch (err) {
      message('storyMsg', '저장하지 못했어요: ' + err.message, true);
    }
  });

  $('storyClear').addEventListener('click', async () => {
    await chrome.storage.local.set({ storyBgImage: '', storyBgName: '' });
    message('storyMsg', '사진을 지웠어요. 원래 배경으로 돌아가요.');
    renderStory();
  });

  renderBgm();
  renderStory();
})();
