(() => {
  'use strict';

  const toggle = document.getElementById('sceneStartPair');
  const positionGroup = document.getElementById('pairPositionGroup');
  const radios = Array.from(document.querySelectorAll('input[name="pairPosition"]'));

  const traceToggle = document.getElementById('traceBackground');
  const jointToggle = document.getElementById('jointWarp');
  const darkToggle = document.getElementById('darkMode');
  const accentGroup = document.getElementById('accentGroup');
  const accentRadios = Array.from(document.querySelectorAll('input[name="accentColor"]'));
  const blueRadios = Array.from(document.querySelectorAll('input[name="blueColor"]'));

  function renderDark(on) {
    accentGroup.classList.toggle('is-disabled', !on);
  }

  function render(settings) {
    darkToggle.checked = !!settings.darkMode;
    renderDark(!!settings.darkMode);
    accentRadios.forEach((r) => {
      r.checked = r.value === settings.accentColor;
    });
    blueRadios.forEach((r) => {
      r.checked = r.value === settings.blueColor;
    });
    traceToggle.checked = !!settings.traceBackground;
    jointToggle.checked = !!settings.jointWarp;
    toggle.checked = !!settings.sceneStartPair;
    positionGroup.disabled = !settings.sceneStartPair;
    radios.forEach((r) => {
      r.checked = r.value === settings.pairPosition;
    });
  }

  function save(patch) {
    chrome.storage.sync.set(patch);
  }

  // ---------- 편리한 코드 모음, 배경음악, 엔트리 이야기 배경 ----------
  const codeToggle = document.getElementById('codeCollection');
  const bgmToggle = document.getElementById('bgm');
  const bgmVolume = document.getElementById('bgmVolume');
  const bgmName = document.getElementById('bgmName');
  const storyToggle = document.getElementById('storyBg');
  const storyDim = document.getElementById('storyBgDim');
  const storyThumb = document.getElementById('storyThumb');
  const storyNone = document.getElementById('storyNone');

  function renderMedia(local) {
    bgmName.textContent = local.bgmName ? '♪ ' + local.bgmName : '음악을 아직 고르지 않았어요';
    storyThumb.hidden = !local.storyBgImage;
    storyNone.hidden = !!local.storyBgImage;
    if (local.storyBgImage) storyThumb.src = local.storyBgImage;
  }

  function renderExtra(settings) {
    codeToggle.checked = !!settings.codeCollection;
    bgmToggle.checked = !!settings.bgm;
    bgmVolume.value = settings.bgmVolume;
    storyToggle.checked = !!settings.storyBg;
    storyDim.value = settings.storyBgDim;
  }

  chrome.storage.sync.get(EASY_ENTRY_DEFAULTS, renderExtra);
  chrome.storage.local.get({ bgmName: '', storyBgImage: '' }, renderMedia);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') chrome.storage.local.get({ bgmName: '', storyBgImage: '' }, renderMedia);
  });

  codeToggle.addEventListener('change', () => save({ codeCollection: codeToggle.checked }));
  bgmToggle.addEventListener('change', () => save({ bgm: bgmToggle.checked }));
  bgmVolume.addEventListener('change', () => save({ bgmVolume: Number(bgmVolume.value) }));
  storyToggle.addEventListener('change', () => save({ storyBg: storyToggle.checked }));
  storyDim.addEventListener('change', () => save({ storyBgDim: Number(storyDim.value) }));

  // 파일 고르기는 따로 열리는 페이지에서 해요(팝업은 파일 창이 열리면 닫혀 버릴 수 있어서).
  document.querySelectorAll('[data-open]').forEach((btn) => {
    btn.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL('popup/media.html#' + btn.dataset.open) });
    });
  });

  chrome.storage.sync.get(EASY_ENTRY_DEFAULTS, render);

  toggle.addEventListener('change', () => {
    positionGroup.disabled = !toggle.checked;
    save({ sceneStartPair: toggle.checked });
  });

  traceToggle.addEventListener('change', () => {
    save({ traceBackground: traceToggle.checked });
  });

  jointToggle.addEventListener('change', () => {
    save({ jointWarp: jointToggle.checked });
  });

  darkToggle.addEventListener('change', () => {
    renderDark(darkToggle.checked);
    save({ darkMode: darkToggle.checked });
  });

  accentRadios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ accentColor: r.value });
    });
  });

  blueRadios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ blueColor: r.value });
    });
  });

  radios.forEach((r) => {
    r.addEventListener('change', () => {
      if (r.checked) save({ pairPosition: r.value });
    });
  });
})();
