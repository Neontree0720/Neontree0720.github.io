// 보이지 않는 페이지에서 배경음악을 틀어요. background.js가 play / stop / reload 를 보내요.
(() => {
  'use strict';

  const audio = document.getElementById('bgm');
  let loadedUrl = null;
  let loading = null;

  async function load() {
    if (loadedUrl) return true;
    if (!loading) {
      loading = (async () => {
        const track = await EasyEntryMediaDB.get('bgm');
        if (!track || !track.blob) return false;
        loadedUrl = URL.createObjectURL(track.blob);
        audio.src = loadedUrl;
        // 지난번에 멈춘 곳부터 이어서
        const saved = Number(localStorage.getItem('pos:' + track.name));
        if (saved > 0) {
          await new Promise((r) => {
            audio.addEventListener('loadedmetadata', r, { once: true });
            setTimeout(r, 1500);
          });
          if (saved < (audio.duration || Infinity)) audio.currentTime = saved;
        }
        audio.dataset.name = track.name;
        return true;
      })().finally(() => {
        loading = null;
      });
    }
    return loading;
  }

  function savePos() {
    if (audio.dataset.name && !audio.paused) localStorage.setItem('pos:' + audio.dataset.name, String(audio.currentTime));
  }

  function unload() {
    audio.pause();
    if (loadedUrl) URL.revokeObjectURL(loadedUrl);
    loadedUrl = null;
    audio.removeAttribute('src');
    audio.load();
  }

  setInterval(savePos, 2000);

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.target !== 'ee-bgm-offscreen') return;
    if (msg.action === 'play') {
      audio.volume = Math.max(0, Math.min(1, (Number(msg.volume) || 0) / 100));
      load().then((ok) => {
        if (ok && audio.paused) audio.play().catch(() => {});
      });
    } else if (msg.action === 'stop') {
      savePos();
      audio.pause();
    } else if (msg.action === 'reload') {
      unload();
    }
  });
})();
