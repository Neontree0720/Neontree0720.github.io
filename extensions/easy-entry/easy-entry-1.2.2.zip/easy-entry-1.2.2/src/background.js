// 확장 프로그램 본체(서비스 워커): 배경음악을 언제 틀고 멈출지 정해요.
// - 엔트리 탭이 하나라도 열려 있고, 배경음악이 켜져 있고, 음악 파일이 있으면 재생
// - 엔트리 탭이 모두 닫히면 멈춤 (페이지를 옮겨 다닐 때 잠깐 끊긴 건 기다려 줘요)
'use strict';

const OFFSCREEN_URL = 'src/offscreen/bgm.html';
const STOP_DELAY = 1500; // 엔트리 안에서 페이지를 옮길 때 bye -> hello 사이 시간

let stopTimer = null;

async function getTabs() {
  const { bgmTabs } = await chrome.storage.session.get({ bgmTabs: [] });
  return new Set(bgmTabs);
}

async function setTabs(set) {
  await chrome.storage.session.set({ bgmTabs: [...set] });
}

async function hasOffscreen() {
  const all = await self.clients.matchAll();
  return all.some((c) => c.url.endsWith(OFFSCREEN_URL));
}

async function ensureOffscreen() {
  if (await hasOffscreen()) return;
  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ['AUDIO_PLAYBACK'],
      justification: '엔트리 페이지에서 사용자가 고른 배경음악을 틀어요.'
    });
  } catch (e) {
    // 이미 만들어져 있으면 괜찮아요.
  }
}

async function shouldPlay() {
  const { bgm, bgmVolume } = await chrome.storage.sync.get({ bgm: true, bgmVolume: 50 });
  const { bgmName } = await chrome.storage.local.get({ bgmName: '' });
  const tabs = await getTabs();
  return { play: !!bgm && !!bgmName && tabs.size > 0, volume: bgmVolume };
}

async function update() {
  const { play, volume } = await shouldPlay();
  if (play) {
    await ensureOffscreen();
    chrome.runtime.sendMessage({ target: 'ee-bgm-offscreen', action: 'play', volume }, () => void chrome.runtime.lastError);
  } else if (await hasOffscreen()) {
    chrome.runtime.sendMessage({ target: 'ee-bgm-offscreen', action: 'stop' }, () => void chrome.runtime.lastError);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== 'ee-bgm') return;
  const tabId = sender.tab && sender.tab.id;
  (async () => {
    const tabs = await getTabs();
    if (msg.action === 'hello' && tabId != null) {
      tabs.add(tabId);
      await setTabs(tabs);
      clearTimeout(stopTimer);
      await update();
    } else if (msg.action === 'bye' && tabId != null) {
      tabs.delete(tabId);
      await setTabs(tabs);
      clearTimeout(stopTimer);
      stopTimer = setTimeout(update, STOP_DELAY);
    } else if (msg.action === 'refresh') {
      await update();
    }
    reply({ ok: true });
  })();
  return true;
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const tabs = await getTabs();
  if (tabs.delete(tabId)) {
    await setTabs(tabs);
    await update();
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if ((area === 'sync' && (changes.bgm || changes.bgmVolume)) || (area === 'local' && changes.bgmId)) {
    if (area === 'local' && changes.bgmId) {
      // 음악을 바꿨으면 새 파일로 다시 불러와요.
      chrome.runtime.sendMessage({ target: 'ee-bgm-offscreen', action: 'reload' }, () => void chrome.runtime.lastError);
    }
    update();
  }
});
