// 엔트리 전체 다크모드 (메인, 커뮤니티, 작품 만들기 등 playentry.org 모든 화면)
// 페이지 안(MAIN 세계)에서 문서가 만들어지자마자(document_start) 실행돼요.
//
// 하는 일
// - 사이트의 CSS 규칙을 모두 읽어서 색(배경/글자/테두리/그림자/그라데이션)을 어두운 화면에 맞게 다시 계산하고,
//   같은 선택자에 !important로 덮어씌워요. (엔트리는 CSS 변수를 안 써서 규칙을 하나하나 바꿔야 해요)
// - 엔트리가 새 스타일을 넣으면(insertRule, <style> 추가) 바로 따라서 처리해요. → 하얗게 번쩍이지 않게
// - 요소에 직접 적힌 style="color: ..." 도 같은 방식으로 바꿔요. (SVG는 블록 색이라 건드리지 않아요)
// - 엔트리 초록색은 설정에서 고른 강조색(보라/초록/흰색/회색/남색)으로 바꿔요.
// - 로고는 엔트리 BI 가이드 2.2의 흑백 로고로 바꿔요.
// - 작품 무대(캔버스), 블록, 그림판 그림, 사진은 건드리지 않아요.
(() => {
  'use strict';

  if (window.__easyEntryDark) return;
  window.__easyEntryDark = true;

  const LOG = '[이지 엔트리 다크모드]';
  const CACHE_KEY = 'easyEntry.dark'; // 다음 페이지에서 바로(설정이 오기 전에) 적용하려고 저장해 둬요
  const OURS = 'data-ee-dark'; // 우리가 만든 <style> 표시

  // 엔트리 BI 가이드 2.2 흑백 로고 (흰 블록, 글자는 뚫려 있어서 배경색이 비쳐요)
  const LOGO_SVG = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 33.88"><path fill="#fff" fill-rule="nonzero" d="M164.72 24.23C164.33 25.22 163.83 25.93 163.26 26.37C162.67 26.81 161.91 27.04 160.98 27.04L158.98 26.98L158.98 24.3L159.41 24.34C159.79 24.37 160.23 24.38 160.74 24.38C161.14 24.38 161.43 24.32 161.61 24.19C161.8 24.05 161.97 23.8 162.12 23.43L162.21 23.22L162.98 21.46L157.19 10.67L160.17 10.67L164.23 18.36L167.21 10.67L170.16 10.67L164.72 24.23M175.64 0.14C175.55 0.05 175.43 0 175.31 0L150.82 0C150.69 0 150.57 0.05 150.48 0.14L146.26 4.36C146.17 4.45 146.12 4.57 146.12 4.69L146.12 11.28C146.12 11.41 146.17 11.53 146.26 11.61L150.39 15.75C151.05 16.4 151.05 17.47 150.39 18.13L146.26 22.26C146.17 22.35 146.12 22.47 146.12 22.6L146.12 29.18C146.12 29.31 146.17 29.43 146.26 29.52L150.48 33.74C150.57 33.83 150.69 33.88 150.82 33.88L175.31 33.88C175.43 33.88 175.55 33.83 175.64 33.74L179.86 29.51C179.95 29.43 180 29.31 180 29.18L180 4.69C180 4.57 179.95 4.45 179.86 4.36L175.64 0.14"/><path fill="#fff" fill-rule="nonzero" d="M132.93 17.22L130.18 17.22L130.18 16.17C130.18 15.11 129.96 14.28 129.53 13.71C129.11 13.16 128.58 12.89 127.88 12.89C126.84 12.89 126.1 13.32 125.6 14.19C125.07 15.12 124.8 16.35 124.8 17.85L124.8 23.95L122.04 23.95L122.04 10.67L124.69 10.67L124.69 11.83C124.95 11.57 125.25 11.32 125.6 11.11C126.38 10.62 127.24 10.37 128.14 10.37C129.63 10.37 130.82 10.89 131.68 11.92C132.51 12.93 132.93 14.34 132.93 16.13L132.93 17.22M147.87 16.68L144.17 12.98C143.72 12.53 143.47 11.92 143.47 11.28L143.47 4.7C143.47 4.57 143.42 4.45 143.33 4.36L139.11 0.14C139.02 0.05 138.9 0 138.78 0L114.29 0C114.16 0 114.04 0.05 113.95 0.14L109.73 4.36C109.64 4.45 109.59 4.57 109.59 4.69L109.59 11.28C109.59 11.41 109.64 11.53 109.73 11.61L113.86 15.75C114.18 16.07 114.36 16.49 114.36 16.94C114.36 17.39 114.18 17.81 113.86 18.13L109.73 22.26C109.64 22.35 109.59 22.47 109.59 22.6L109.59 29.18C109.59 29.31 109.64 29.43 109.73 29.52L113.95 33.74C114.04 33.83 114.16 33.88 114.29 33.88L138.78 33.88C138.9 33.88 139.02 33.83 139.11 33.74L143.33 29.52C143.42 29.43 143.47 29.31 143.47 29.18L143.47 22.6C143.47 21.96 143.72 21.35 144.17 20.9L147.87 17.2C148.02 17.05 148.02 16.82 147.87 16.68"/><path fill="#fff" fill-rule="nonzero" d="M96.41 20.32C96.41 21.36 96.02 22.28 95.25 23.05C94.49 23.84 93.4 24.23 92.04 24.23C90.77 24.23 89.67 23.79 88.76 22.91C87.85 22.02 87.38 20.76 87.38 19.17L87.38 13.19L83.59 13.19L83.59 10.67L87.38 10.67L87.38 7.21L89.98 7.21L89.98 10.67L95.17 10.67L95.17 13.19L89.98 13.19L89.98 19.18C89.98 20.08 90.18 20.74 90.59 21.12C91 21.52 91.48 21.71 92.06 21.71C92.6 21.71 93.01 21.58 93.32 21.3C93.63 21.03 93.79 20.69 93.81 20.29L93.84 19.92L96.41 19.92L96.41 20.32M111.35 16.68L107.64 12.98C107.19 12.53 106.94 11.92 106.94 11.28L106.94 4.69C106.94 4.57 106.89 4.45 106.8 4.36L102.58 0.14C102.49 0.05 102.37 0 102.25 0L77.75 0C77.63 0 77.51 0.05 77.42 0.14L73.2 4.36C73.11 4.45 73.06 4.57 73.06 4.69L73.06 11.28C73.06 11.41 73.11 11.53 73.2 11.61L77.33 15.75C77.65 16.07 77.83 16.49 77.83 16.94C77.83 17.39 77.65 17.81 77.33 18.13L73.2 22.26C73.11 22.35 73.06 22.47 73.06 22.6L73.06 29.18C73.06 29.31 73.11 29.43 73.2 29.51L77.42 33.74C77.51 33.83 77.63 33.88 77.75 33.88L102.25 33.88C102.37 33.88 102.49 33.83 102.58 33.74L106.8 29.52C106.89 29.43 106.94 29.31 106.94 29.18L106.94 22.6C106.94 21.96 107.19 21.35 107.64 20.9L111.35 17.2C111.49 17.05 111.49 16.82 111.35 16.68"/><path fill="#fff" fill-rule="nonzero" d="M60.38 23.95L57.63 23.95L57.63 16.12C57.63 15.07 57.38 14.26 56.89 13.7C56.4 13.16 55.73 12.89 54.83 12.89C53.74 12.89 52.92 13.26 52.35 14.03C51.76 14.83 51.45 15.94 51.45 17.34L51.45 23.95L48.86 23.95L48.86 10.67L51.41 10.67L51.41 11.75C51.73 11.45 52.1 11.18 52.52 10.97C53.28 10.57 54.1 10.37 54.96 10.37C56.69 10.37 58.04 10.9 58.98 11.93C59.91 12.96 60.38 14.43 60.38 16.29L60.38 23.95M74.82 16.68L71.11 12.98C70.66 12.53 70.41 11.92 70.41 11.28L70.41 4.69C70.41 4.57 70.36 4.45 70.27 4.36L66.05 0.14C65.96 0.05 65.84 0 65.71 0L41.22 0C41.1 0 40.98 0.05 40.89 0.14L36.67 4.36C36.58 4.45 36.53 4.57 36.53 4.69L36.53 11.28C36.53 11.41 36.58 11.53 36.67 11.61L40.8 15.75C41.12 16.07 41.29 16.49 41.29 16.94C41.29 17.39 41.12 17.81 40.8 18.13L36.67 22.26C36.58 22.35 36.53 22.47 36.53 22.6L36.53 29.18C36.53 29.31 36.58 29.43 36.67 29.51L40.89 33.74C40.98 33.83 41.1 33.88 41.22 33.88L65.72 33.88C65.84 33.88 65.96 33.83 66.05 33.74L70.27 29.52C70.36 29.43 70.41 29.31 70.41 29.18L70.41 22.6C70.41 21.96 70.66 21.35 71.11 20.9L74.82 17.2C74.96 17.05 74.96 16.82 74.82 16.68"/><path fill="#fff" fill-rule="nonzero" d="M17.15 12.89C16.21 12.89 15.48 13.18 14.92 13.78C14.44 14.31 14.1 14.97 13.92 15.77L20.32 15.77C20.19 14.96 19.88 14.29 19.39 13.77C18.82 13.18 18.09 12.89 17.15 12.89"/><path fill="#fff" fill-rule="nonzero" d="M23.04 18.29L13.79 18.29C13.92 19.31 14.29 20.12 14.88 20.71C15.56 21.38 16.43 21.71 17.55 21.71C18.83 21.71 19.91 21.25 20.82 20.11L21.08 19.68L22.97 21.43L22.73 21.72C21.33 23.39 19.59 24.23 17.55 24.23C15.58 24.23 13.98 23.59 12.8 22.31C11.62 21.05 11.03 19.38 11.03 17.37C11.03 15.4 11.58 13.74 12.66 12.41C13.76 11.06 15.25 10.37 17.09 10.37C18.45 10.37 19.62 10.73 20.56 11.44C21.49 12.15 22.15 13 22.53 13.97C22.89 14.92 23.07 15.95 23.07 17.03L23.04 18.29M38.28 16.68L34.58 12.98C34.13 12.53 33.88 11.92 33.88 11.28L33.88 4.69C33.88 4.57 33.83 4.45 33.74 4.36L29.52 0.14C29.43 0.05 29.31 0 29.18 0L4.69 0C4.57 0 4.45 0.05 4.36 0.14L0.14 4.36C0.05 4.45 0 4.57 0 4.69L0 29.18C0 29.31 0.05 29.43 0.14 29.52L4.36 33.74C4.45 33.83 4.57 33.88 4.69 33.88L29.18 33.88C29.31 33.88 29.43 33.83 29.52 33.74L33.74 29.52C33.83 29.43 33.88 29.31 33.88 29.18L33.88 22.6C33.88 21.96 34.13 21.35 34.58 20.9L38.28 17.2C38.43 17.05 38.43 16.82 38.28 16.68"/></svg>';
  // 괄호/따옴표까지 인코딩해야 CSS url() 안에서 안 깨져요.
  const LOGO_URL = 'url("data:image/svg+xml,' + encodeURIComponent(LOGO_SVG).replace(/[()'"]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase()) + '")';
  const LOGO_PATTERN = /CommonEntryLogo|CommonFooterLogo|\/img\/ws\/entry_logo/i;
  const DARK_TEXT_LOGO_PATTERN = /CommonNaverConnectLogo/i; // 검은 글씨 로고 → 밝게 뒤집기

  // 바꿀 색: base = 버튼/표시 배경, text = 어두운 배경 위 글자, on = base 위 글자
  const ACCENTS = {
    purple: { base: [110, 90, 230], text: [172, 160, 247], on: [255, 255, 255] }, // 엔트리 퍼플 #6E5AE6
    green: { base: [50, 210, 125], text: [120, 228, 168], on: [255, 255, 255] }, // 엔트리 그린 #32D27D
    blue: { base: [79, 128, 255], text: [146, 176, 255], on: [255, 255, 255] }, // 엔트리 작품 만들기 파랑 #4F80FF
    white: { base: [232, 233, 238], text: [238, 239, 243], on: [28, 30, 36] },
    gray: { base: [107, 114, 128], text: [190, 195, 204], on: [255, 255, 255] },
    navy: { base: [47, 63, 143], text: [152, 168, 232], on: [255, 255, 255] }
  };

  // 어두운 화면 기본 색
  const PAGE_BG = '#17191e';

  // 커뮤니티 글쓰기 편집기(네이버 스마트에디터): CSS가 다른 사이트(pstatic.net)에 있어서 바로는 못 읽어요.
  // 따로 받아서 같은 방식으로 어둡게 바꾸되, !important 없이 넣어요. 그래야 사용자가 고른 글자색(직접 적힌 색)이 그대로 보여요.
  // 글 안의 검은 글씨/흰 글씨만 화면에서 서로 바꿔 보여 줘요(저장되는 글은 그대로라 다크모드를 안 쓰는 사람에게도 원래대로).
  const EDITOR_CONTENT = '.se-root .se-contenteditable';
  const FOREIGN_CSS_HOST = /(^|\.)pstatic\.net$/i;

  // accentColor: 엔트리 초록 대신 쓸 색('green' = 원래 색 그대로)
  // blueColor: 엔트리 UI 파랑 대신 쓸 색('blue' = 원래 색 그대로)
  const settings = { darkMode: true, accentColor: 'purple', blueColor: 'purple' };
  try {
    const cached = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
    if (cached && typeof cached.darkMode === 'boolean') settings.darkMode = cached.darkMode;
    if (cached && typeof cached.accentColor === 'string' && cached.accentColor in ACCENTS) settings.accentColor = cached.accentColor;
    if (cached && typeof cached.blueColor === 'string' && cached.blueColor in ACCENTS) settings.blueColor = cached.blueColor;
  } catch (e) {
    // 저장소를 못 쓰면 기본값
  }

  // ---------- 색 계산 ----------

  const NAMED = {
    white: [255, 255, 255], black: [0, 0, 0], red: [255, 0, 0], green: [0, 128, 0], blue: [0, 0, 255],
    gray: [128, 128, 128], grey: [128, 128, 128], silver: [192, 192, 192], whitesmoke: [245, 245, 245],
    gainsboro: [220, 220, 220], lightgray: [211, 211, 211], lightgrey: [211, 211, 211], darkgray: [169, 169, 169],
    darkgrey: [169, 169, 169], dimgray: [105, 105, 105], dimgrey: [105, 105, 105], ghostwhite: [248, 248, 255],
    snow: [255, 250, 250], ivory: [255, 255, 240], aliceblue: [240, 248, 255], navy: [0, 0, 128],
    yellow: [255, 255, 0], orange: [255, 165, 0], purple: [128, 0, 128]
  };
  const COLOR_TOKEN = /rgba?\([^()]*\)|#[0-9a-f]{3,8}\b|\b(?:white|black|red|green|blue|gray|grey|silver|whitesmoke|gainsboro|lightgr[ae]y|darkgr[ae]y|dimgr[ae]y|ghostwhite|snow|ivory|aliceblue|navy|yellow|orange|purple)\b/gi;

  function parseColor(str) {
    const s = str.trim().toLowerCase();
    if (s[0] === '#') {
      let h = s.slice(1);
      if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join('');
      if (h.length !== 6 && h.length !== 8) return null;
      const n = (i) => parseInt(h.slice(i, i + 2), 16);
      return { r: n(0), g: n(2), b: n(4), a: h.length === 8 ? n(6) / 255 : 1 };
    }
    if (s.startsWith('rgb')) {
      const nums = s.slice(s.indexOf('(') + 1, s.lastIndexOf(')')).split(/[\s,/]+/).filter(Boolean);
      if (nums.length < 3) return null;
      const ch = (v) => (v.endsWith('%') ? (parseFloat(v) * 255) / 100 : parseFloat(v));
      const a = nums[3] === undefined ? 1 : nums[3].endsWith('%') ? parseFloat(nums[3]) / 100 : parseFloat(nums[3]);
      const c = { r: ch(nums[0]), g: ch(nums[1]), b: ch(nums[2]), a };
      return [c.r, c.g, c.b, c.a].every((v) => Number.isFinite(v)) ? c : null;
    }
    const named = NAMED[s];
    return named ? { r: named[0], g: named[1], b: named[2], a: 1 } : null;
  }

  function toHsl({ r, g, b }) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    if (max === min) return { h: 0, s: 0, l };
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    let h;
    if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
    else if (max === g) h = (b - r) / d + 2;
    else h = (r - g) / d + 4;
    return { h: h * 60, s, l };
  }

  function fromHsl(h, s, l) {
    h = (((h % 360) + 360) % 360) / 360;
    if (s === 0) return [l * 255, l * 255, l * 255];
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    const f = (t) => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
  }

  function fmt(rgb, a) {
    const [r, g, b] = rgb.map((v) => Math.max(0, Math.min(255, Math.round(v))));
    return a >= 1 ? `rgb(${r}, ${g}, ${b})` : `rgba(${r}, ${g}, ${b}, ${Math.round(a * 1000) / 1000})`;
  }

  // 엔트리 초록 계열인지
  function isEntryGreen(h, s, l) {
    return h >= 95 && h <= 175 && s >= 0.35 && l >= 0.18 && l <= 0.93;
  }

  // 엔트리 UI 파랑 계열인지 (#4F80FF 등)
  function isEntryBlue(h, s, l) {
    return h >= 205 && h <= 232 && s >= 0.55 && l >= 0.35 && l <= 0.93;
  }

  // 원래 색 그대로 두는 선택이면 null
  function greenAccent() {
    return settings.accentColor === 'green' ? null : ACCENTS[settings.accentColor] || null;
  }
  function blueAccent() {
    return settings.blueColor === 'blue' ? null : ACCENTS[settings.blueColor] || null;
  }

  // 이 색을 바꿀 강조색(초록이면 초록 대신 색, 파랑이면 파랑 대신 색). 해당 없으면 null
  function accentFor(c, noAccent) {
    const info = accentInfo(c, noAccent);
    return info ? info.ac : null;
  }

  // { ac: 바꿀 강조색, ref: 원래 엔트리 기준색 } | null
  function accentInfo(c, noAccent) {
    if (noAccent || c.a === 0) return null;
    const { h, s, l } = toHsl(c);
    if (isEntryGreen(h, s, l)) {
      const ac = greenAccent();
      return ac ? { ac, ref: ACCENTS.green.base } : null;
    }
    if (isEntryBlue(h, s, l)) {
      const ac = blueAccent();
      return ac ? { ac, ref: ACCENTS.blue.base } : null;
    }
    return null;
  }

  function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
  }

  // role: bg | text | border | fill | shadow
  // noAccent: 블록 카테고리처럼 원래 색을 지켜야 하는 곳
  function transformColor(c, role, noAccent) {
    if (c.a === 0) return null;
    const { h, s, l } = toHsl(c);
    const info = accentInfo(c, noAccent);
    const vivid = s >= 0.45 && l >= 0.25 && l <= 0.78;

    if (info) {
      const ac = info.ac;
      if (role === 'text' || role === 'fill') return fmt(ac.text, c.a);
      if (role === 'shadow') return fmt([0, 0, 0], c.a);
      const A = toHsl({ r: ac.base[0], g: ac.base[1], b: ac.base[2] });
      const R = toHsl({ r: info.ref[0], g: info.ref[1], b: info.ref[2] });
      if (l > 0.82) {
        // 연한 배경 → 강조색이 살짝 섞인 어두운 배경 (연할수록 더 어둡게: 단계 구분이 남아요)
        return fmt(fromHsl(A.h, Math.min(A.s, 0.5) * 0.75, 0.16 + (1 - l) * 0.6), c.a);
      }
      // 원래 기준색보다 밝거나 어두운 만큼 강조색도 밝거나 어둡게 (속도 단계 등 색 구분 유지)
      const l2 = clamp(A.l + (l - R.l) * 0.9, 0.15, 0.95);
      const s2 = clamp(A.s * (s / Math.max(R.s, 0.01)), 0.08, 1);
      return fmt(fromHsl(A.h, s2, l2), c.a);
    }

    switch (role) {
      case 'bg': {
        if (vivid) return null; // 진한 색 버튼/표시는 그대로
        if (l >= 0.45) {
          const l2 = 0.105 + (1 - l) * 0.32; // 흰색 → 아주 어두운 회색
          const s2 = Math.min(s, 0.3) * (l > 0.85 ? 0.55 : 0.85);
          return fmt(fromHsl(h, s2, l2), c.a);
        }
        return null; // 원래 어두운 배경은 그대로
      }
      case 'border': {
        if (vivid) return null;
        if (l >= 0.45) return fmt(fromHsl(h, Math.min(s, 0.2), 0.2 + (1 - l) * 0.3), c.a);
        return null;
      }
      case 'text':
      case 'fill': {
        if (l > 0.62) return null; // 원래 밝은 글자는 그대로
        if (s > 0.35) return fmt(fromHsl(h, Math.min(1, s), Math.max(0.68, 1 - l * 0.5)), c.a); // 색 있는 글자: 색은 살리고 밝게
        return fmt(fromHsl(h, Math.min(s, 0.12), 0.93 - l * 0.45), c.a); // 검정/회색 글자 → 밝은 회색
      }
      case 'shadow': {
        if (l > 0.5) return fmt([0, 0, 0], Math.min(1, c.a * 0.8));
        return null;
      }
      default:
        return null;
    }
  }

  const colorCache = new Map();

  // 값 안의 색을 모두 바꿔요. 바뀐 게 없으면 null
  function transformValue(value, role, noAccent) {
    if (!value || value.indexOf('var(') >= 0) return null;
    const key = role + '|' + (noAccent ? 1 : 0) + '|' + value;
    if (colorCache.has(key)) return colorCache.get(key);
    let changed = false;
    const out = value.replace(COLOR_TOKEN, (tok) => {
      const c = parseColor(tok);
      if (!c) return tok;
      const t = transformColor(c, role, noAccent);
      if (t === null) return tok;
      changed = true;
      return t;
    });
    const res = changed ? out : null;
    colorCache.set(key, res);
    return res;
  }

  function firstColor(value) {
    const m = value && value.match(COLOR_TOKEN);
    return m ? parseColor(m[0]) : null;
  }

  function isLight(value) {
    const c = firstColor(value);
    return !!c && toHsl(c).l > 0.6;
  }

  // CSS 값 안의 상대 주소(url(../images/a.svg))를 원래 CSS 파일 기준 절대 주소로 바꿔요.
  // 덮어쓰는 <style>은 페이지 주소 기준이라, 안 바꾸면 그림을 못 찾아요.
  function absolutizeUrls(value, base) {
    return value.replace(/url\((["']?)([^"')]+)\1\)/g, (m, q, u) => {
      if (/^(data:|blob:|https?:|#)/i.test(u)) return m;
      try {
        return 'url("' + new URL(u, base || location.href).href + '")';
      } catch (e) {
        return m;
      }
    });
  }

  // ---------- 규칙 하나 → 덮어쓸 선언들 ----------

  const SIMPLE_PROPS = [
    ['background-color', 'bg'],
    ['border-top-color', 'border'],
    ['border-right-color', 'border'],
    ['border-bottom-color', 'border'],
    ['border-left-color', 'border'],
    ['outline-color', 'border'],
    ['column-rule-color', 'border'],
    ['color', 'text'],
    ['caret-color', 'text'],
    ['-webkit-text-fill-color', 'text'],
    ['text-decoration-color', 'text'],
    ['fill', 'fill'],
    ['stroke', 'fill']
  ];

  // 블록/무대 쪽 SVG 색은 건드리지 않아요.
  const SKIP_FILL_SELECTOR = /block|board|pattern|stage|entryCanvas|paint/i;

  // ---------- 사이트 그림(SVG/PNG) 색 바꾸기 ----------
  // 엔트리 자체 그림(/lib/, /img/ 아래 .svg .png .gif)만 바꿔요. 사용자가 올린 사진(/uploads/)은 그대로.
  // - 이름이 배경/썸네일인 SVG(entry_bg, BgStaffPick, DefaultCardThmb...): 밝은 색 → 어두운 색
  // - 색이 안 적힌 SVG 아이콘(기본 검정): 밝은 기본색 지정
  // - 진한 단색 아이콘(흰색 없음): 어두운 색 → 밝은 색
  // - 나머지는 실제로 그려서 픽셀을 살펴봐요:
  //     흰 바탕 버튼(불투명하고 대부분 밝음) → 바탕은 어둡게, 아이콘은 밝게, 파랑/초록은 강조색으로
  //     검은 단색 아이콘(불투명한 부분이 대부분 어두움) → 밝게
  //     그 밖(색 많은 그림, 흰 아이콘 등) → 그대로
  // 바꾼 그림은 blob: 주소로 넣어요(엔트리 페이지는 이미지로 blob:을 허용하고, 주소가 짧아 CSS가 커지지 않아요).

  const PENDING = 'pending';
  const assetCache = new Map(); // 절대 주소 → blob URL | null | PENDING
  const SVG_COLOR_ATTR = /(fill|stroke|stop-color|flood-color)(\s*=\s*["']\s*|\s*:\s*)(#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)|[a-zA-Z]+)/g;
  const BG_NAME = /(^|[\/_\-.])bg|Bg[A-Z0-9]|background|thmb|thumb/i;
  const ASSET_PATH = /^\/(lib|img)\//;
  const ASSET_EXT = /\.(svg|png|gif)$/i;
  const PLAYER_ICON_PATH = /\/img\/assets\/project\//i;
  let refreshTimer = 0;

  function resolveUrl(u, base) {
    try {
      const url = new URL(u, base || location.href);
      if (url.origin !== location.origin) return null;
      if (!ASSET_PATH.test(url.pathname) || !ASSET_EXT.test(url.pathname)) return null;
      return url.href;
    } catch (e) {
      return null;
    }
  }

  function recoloredSvg(abs) {
    if (!abs) return null;
    const hit = assetCache.get(abs);
    if (hit === undefined) {
      assetCache.set(abs, PENDING);
      loadAsset(abs);
      return null;
    }
    return hit === PENDING ? null : hit;
  }

  async function loadAsset(abs) {
    let result = null;
    try {
      const isSvg = /\.svg$/i.test(new URL(abs).pathname);
      if (isSvg) {
        const res = await fetch(abs, { credentials: 'same-origin' });
        if (res.ok) {
          const text = await res.text();
          let out = recolorSvgText(text, abs);
          if (out === undefined) {
            // 규칙으로 못 정했으면 그려 보고 정해요.
            const kind = classify(await measure(URL.createObjectURL(new Blob([text], { type: 'image/svg+xml' }))));
            out = kind ? recolorSvgByKind(text, kind) : null;
          }
          if (out) result = URL.createObjectURL(new Blob([out], { type: 'image/svg+xml' }));
        }
      } else {
        result = await recolorRaster(abs);
      }
    } catch (e) {
      result = null;
    }
    assetCache.set(abs, result);
    if (result) scheduleRefresh();
  }

  // 오브젝트 추가하기 창의 버튼 그림(CSS 안에 PNG로 박혀 있음): 파일 올리기, 글상자 글자색 버튼,
  // 벡터 표시, 고른 오브젝트 지우기(X) 등. 이 창 것만 바꿔요(머리 막대 버튼 등은 지금 모습 그대로).
  const DATA_RASTER_TARGET = /(imbtn|imico)_pop|obj_list|select_list|btn_del/i;

  // 페이지에 박힌 data: SVG(그림판 아이콘 등)도 같은 방식으로 바꿔요. 주소 전체를 열쇠로 기억해요.
  function recoloredData(u, selector) {
    if (!u) return null;
    const isSvg = u.indexOf('data:image/svg+xml') === 0;
    const isRaster = !isSvg && /^data:image\/(png|gif)/i.test(u) && !!selector && DATA_RASTER_TARGET.test(selector);
    if (!isSvg && !isRaster) return null;
    const hit = assetCache.get(u);
    if (hit === undefined) {
      assetCache.set(u, PENDING);
      if (isSvg) loadDataSvg(u);
      else loadDataRaster(u);
      return null;
    }
    return hit === PENDING ? null : hit;
  }

  async function loadDataRaster(u) {
    let result = null;
    try {
      result = await recolorRaster(u, classifyDataRaster);
    } catch (e) {
      result = null;
    }
    assetCache.set(u, result);
    if (result) scheduleRefresh();
  }

  function decodeDataSvg(u) {
    const comma = u.indexOf(',');
    if (comma < 0) return null;
    const head = u.slice(0, comma);
    const body = u.slice(comma + 1);
    if (/;base64/i.test(head)) {
      const bin = atob(body.replace(/\s/g, ''));
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder('utf-8').decode(bytes);
    }
    return decodeURIComponent(body);
  }

  async function loadDataSvg(u) {
    let result = null;
    try {
      const text = decodeDataSvg(u);
      if (text) {
        let out = recolorSvgText(text, 'inline.svg');
        if (out === undefined) {
          const kind = classify(await measure(URL.createObjectURL(new Blob([text], { type: 'image/svg+xml' }))));
          out = kind ? recolorSvgByKind(text, kind) : null;
        }
        if (out) result = URL.createObjectURL(new Blob([out], { type: 'image/svg+xml' }));
      }
    } catch (e) {
      result = null;
    }
    assetCache.set(u, result);
    if (result) scheduleRefresh();
  }

  // 반환: 바꾼 SVG 글자 | null(그대로 둠) | undefined(그려 봐야 앎)
  function recolorSvgText(text, abs) {
    if (!text || text.indexOf('<svg') < 0) return null;
    const name = abs.split('?')[0].split('/').pop();
    let hasDark = false;
    let hasWhite = false;
    let colorCount = 0;
    text.replace(SVG_COLOR_ATTR, (m, attr, sep, val) => {
      const c = parseColor(val);
      if (c) colorCount++;
      if (c && c.a > 0) {
        const { s, l } = toHsl(c);
        if (l < 0.45 && s < 0.45) hasDark = true;
        if (l > 0.88) hasWhite = true;
      }
      return m;
    });
    // 색이 하나도 안 적힌 아이콘은 기본색(검정)으로 그려져요 → 밝은 기본색을 지정해요.
    if (!colorCount && !BG_NAME.test(name)) {
      const light = transformColor({ r: 0, g: 0, b: 0, a: 1 }, 'fill');
      return light ? text.replace(/<svg\b/, '<svg fill="' + light + '"') : null;
    }
    if (BG_NAME.test(name)) return replaceSvgColors(text, (c) => transformColor(c, 'bg'));
    if (hasDark && !hasWhite) return replaceSvgColors(text, (c) => transformColor(c, 'fill'));
    if (hasWhite) return undefined;
    // 작품 실행 화면의 정지/일시정지 같은 초록 버튼 그림: 초록(파랑)만 강조색으로
    if (PLAYER_ICON_PATH.test(abs)) return replaceSvgColors(text, (c) => (accentInfo(c) ? transformColor(c, 'bg') : null));
    return null;
  }

  function replaceSvgColors(text, fn) {
    let changed = false;
    const out = text.replace(SVG_COLOR_ATTR, (m, attr, sep, val) => {
      const c = parseColor(val);
      if (!c) return m;
      const t = fn(c);
      if (!t) return m;
      changed = true;
      return attr + sep + t;
    });
    return changed ? out : null;
  }

  // 흰 바탕 버튼 / 검은 단색 아이콘에 맞게 색 하나를 바꿔요(SVG, PNG 픽셀 공통).
  function mapForKind(c, kind) {
    const { s, l } = toHsl(c);
    if (kind === 'lightButton') {
      // 아주 밝은 색(흰 바탕)만 바탕으로 보고 어둡게, 그보다 진한 회색은 기호로 보고 밝게
      if (l > 0.85) return transformColor(c, 'bg');
      if (s < 0.45) {
        const h = toHsl(c).h;
        return fmt(fromHsl(h, Math.min(s, 0.25), Math.min(0.93, Math.max(0.7, 0.95 - l * 0.3))), c.a === undefined ? 1 : c.a);
      }
      return transformColor(c, 'fill'); // 색 있는 부분: 파랑/초록은 강조색, 나머지는 그대로
    }
    if (kind === 'darkGlyph') {
      if (l < 0.45 && s < 0.45) return transformColor(c, 'text');
      return null;
    }
    if (kind === 'tinted') {
      // 연회색 동그라미/네모 위 흰 기호(X, 연필 등): 바탕은 어두운 회색, 기호는 밝게
      const a = c.a === undefined ? 1 : c.a;
      const h = toHsl(c).h;
      if (l > 0.85) return fmt(fromHsl(h, Math.min(s, 0.15), 0.9), a);
      if (l > 0.45 && s < 0.5) return fmt(fromHsl(h, Math.min(s, 0.2), 0.22 + (l - 0.45) * 0.25), a);
      return null;
    }
    return null;
  }

  function recolorSvgByKind(text, kind) {
    return replaceSvgColors(text, (c) => mapForKind(c, kind));
  }

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = src;
    });
  }

  // 그림을 작게 그려서 불투명한 부분이 얼마나 되는지, 그중 밝은/어두운 부분이 얼마나 되는지 재요.
  async function measure(src) {
    const img = await loadImage(src);
    const w0 = img.naturalWidth || 64, h0 = img.naturalHeight || 64;
    const k = Math.min(1, 96 / Math.max(w0, h0));
    const w = Math.max(1, Math.round(w0 * k)), h = Math.max(1, Math.round(h0 * k));
    const cv = document.createElement('canvas');
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0, w, h);
    const d = ctx.getImageData(0, 0, w, h).data;
    let opaque = 0, light = 0, dark = 0, mid = 0, edge = 0, edgeOpaque = 0, edgeLight = 0;
    for (let i = 0; i < d.length; i += 4) {
      const px = (i / 4) % w, py = Math.floor(i / 4 / w);
      const onEdge = px === 0 || py === 0 || px === w - 1 || py === h - 1;
      if (onEdge) edge++;
      if (d[i + 3] < 128) continue;
      opaque++;
      const { s, l } = toHsl({ r: d[i], g: d[i + 1], b: d[i + 2] });
      const isLight = l > 0.8 || (l > 0.75 && s < 0.3); // 흰색·연회색·파스텔
      if (isLight) light++;
      else if (l < 0.4 && s < 0.4) dark++;
      else if (l > 0.45 && s < 0.5) mid++;
      if (onEdge) {
        edgeOpaque++;
        if (isLight) edgeLight++;
      }
    }
    const total = w * h;
    return {
      size: Math.max(w0, h0),
      coverage: opaque / total,
      lightFrac: opaque ? light / opaque : 0,
      darkFrac: opaque ? dark / opaque : 0,
      midFrac: opaque ? mid / opaque : 0,
      edgeOpaqueFrac: edge ? edgeOpaque / edge : 0,
      edgeLightFrac: edgeOpaque ? edgeLight / edgeOpaque : 0
    };
  }

  // 버튼/아이콘 크기(128px 이하)만 바꿔요. 큰 흰 바탕 그림은 일러스트일 수 있어서 그대로 둬요.
  function classify(m) {
    if (!m || m.size > 128) return null;
    if (m.coverage >= 0.35 && m.lightFrac >= 0.5) return 'lightButton';
    // 가장자리가 흰색인 작은 아이콘(흰 테두리/바탕 위 기호): 흰 부분을 바탕으로 봐요.
    if (m.edgeOpaqueFrac >= 0.5 && m.edgeLightFrac >= 0.6) return 'lightButton';
    // 64px 이하 작은 아이콘: 밝은 부분이 일부(15~90%)만 있어도 바탕으로 봐요.
    // (전부 흰 아이콘은 색 있는 버튼 위 기호라서 그대로 둬요)
    if (m.size <= 64 && m.lightFrac >= 0.15 && m.lightFrac <= 0.9) return 'lightButton';
    if (m.coverage > 0 && m.darkFrac >= 0.5) return 'darkGlyph';
    return null;
  }

  // CSS 안 data: PNG(오브젝트 추가하기 창 버튼)용: 버튼 묶음 그림(132x80)까지 봐요.
  function classifyDataRaster(m) {
    if (!m || m.size > 140) return null;
    if (m.lightFrac >= 0.99) return null; // 전부 흰 기호는 색 있는 바탕 위라서 그대로
    if (m.midFrac >= 0.5 && m.lightFrac >= 0.02 && m.lightFrac < 0.5) return 'tinted';
    return classify(Object.assign({}, m, { size: Math.min(m.size, 128) }));
  }

  // 그림 가장자리에서 이어지는 밝은 픽셀(바탕)을 찾아요. 반환: 픽셀마다 1(바탕) / 0
  function edgeLightMask(d, w, h) {
    const mask = new Uint8Array(w * h);
    const isLight = (p) => {
      const i = p * 4;
      if (d[i + 3] === 0) return false;
      return toHsl({ r: d[i], g: d[i + 1], b: d[i + 2] }).l > 0.75;
    };
    const stack = [];
    const push = (x, y) => {
      if (x < 0 || y < 0 || x >= w || y >= h) return;
      const p = y * w + x;
      if (mask[p] || !isLight(p)) return;
      mask[p] = 1;
      stack.push(p);
    };
    for (let x = 0; x < w; x++) {
      push(x, 0);
      push(x, h - 1);
    }
    for (let y = 0; y < h; y++) {
      push(0, y);
      push(w - 1, y);
    }
    while (stack.length) {
      const p = stack.pop();
      const x = p % w, y = (p - x) / w;
      push(x + 1, y);
      push(x - 1, y);
      push(x, y + 1);
      push(x, y - 1);
    }
    return mask;
  }

  async function recolorRaster(abs, classifyFn) {
    const kind = (classifyFn || classify)(await measure(abs));
    if (!kind) return null;
    const img = await loadImage(abs);
    const w = img.naturalWidth, h = img.naturalHeight;
    if (!w || !h || w * h > 2048 * 2048) return null;
    const cv = document.createElement('canvas');
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0);
    const imageData = ctx.getImageData(0, 0, w, h);
    const d = imageData.data;
    // 연회색 동그라미 버튼(벡터 표시 등)은 흰 네모 바탕 위에 그려져 있어요.
    // 가장자리와 이어진 밝은 부분(네모 바탕)은 투명하게 지워서 동그라미만 남겨요. 안쪽 흰 기호는 그대로 밝게.
    const clear = kind === 'tinted' ? edgeLightMask(d, w, h) : null;
    const memo = new Map();
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue;
      const key = (d[i] << 16) | (d[i + 1] << 8) | d[i + 2];
      let rgb = memo.get(key);
      if (rgb === undefined) {
        const t = mapForKind({ r: d[i], g: d[i + 1], b: d[i + 2], a: 1 }, kind);
        const c = t ? parseColor(t) : null;
        rgb = c ? [c.r, c.g, c.b] : null;
        memo.set(key, rgb);
      }
      if (rgb) {
        d[i] = rgb[0];
        d[i + 1] = rgb[1];
        d[i + 2] = rgb[2];
      }
      if (clear && clear[i / 4]) d[i + 3] = 0;
    }
    ctx.putImageData(imageData, 0, 0);
    const blob = await new Promise((resolve) => cv.toBlob(resolve, 'image/png'));
    return blob ? URL.createObjectURL(blob) : null;
  }

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      if (!active) return;
      processAllSheets();
      processSvgImages(document);
      processImgs(document);
    }, 60);
  }

  // ---------- SVG 안의 버튼 그림(<image>) ----------
  // 코딩 영역 확대/축소 버튼처럼 SVG 안에 그림으로 들어간 버튼. 블록 아이콘 등은 건드리지 않아요.
  const IMAGE_TARGET = /btn_|button|layers_icon|zoom/i;
  const XLINK = 'http://www.w3.org/1999/xlink';

  function currentImageHref(img) {
    const a = img.getAttributeNS(XLINK, 'href');
    const b = img.getAttribute('href');
    if (a && a.indexOf('blob:') !== 0) return a;
    if (b && b.indexOf('blob:') !== 0) return b;
    return null; // 이미 우리 그림
  }

  function processSvgImage(img) {
    const orig = currentImageHref(img);
    if (!orig || !IMAGE_TARGET.test(orig)) return;
    const rec = recoloredSvg(resolveUrl(orig, location.href));
    if (!rec) return;
    img.setAttribute('data-ee-href', orig);
    img.setAttribute('href', rec);
    img.setAttributeNS(XLINK, 'xlink:href', rec);
  }

  function processSvgImages(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.tagName === 'image') processSvgImage(root);
    root.querySelectorAll('image').forEach(processSvgImage);
  }

  function restoreSvgImages() {
    document.querySelectorAll('image[data-ee-href]').forEach((img) => {
      const orig = img.getAttribute('data-ee-href');
      img.setAttribute('href', orig);
      img.setAttributeNS(XLINK, 'xlink:href', orig);
      img.removeAttribute('data-ee-href');
    });
  }

  // ---------- 페이지에 직접 그려진 작은 SVG 아이콘 (그림판 위쪽 도구 막대 등) ----------
  // 64px 이하의 인라인 <svg>만 바꿔요. 블록 코딩 영역/블록 꾸러미/카테고리 안은 블록이라 건드리지 않아요.
  const SVG_ICON_SKIP = '.entryBoard, .blockMenu, .entryWorkspaceBoard, .entryCategoryListWorkspace, .entryBlockMenuWorkspace';
  const SVG_ATTRS = ['fill', 'stroke', 'stop-color'];
  const svgTouched = new Map(); // 요소 → { attr: [원래 값, 우리가 넣은 값] }

  function svgIconSize(svg) {
    const w = parseFloat(svg.getAttribute('width'));
    const h = parseFloat(svg.getAttribute('height'));
    if (w > 0 && h > 0) return Math.max(w, h);
    const r = svg.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? Math.max(r.width, r.height) : 0;
  }

  function processInlineSvg(svg) {
    if (!svg || svg.tagName !== 'svg' || svg.ownerSVGElement) return;
    if (svg.closest(SVG_ICON_SKIP)) return;
    // 블록이 들어 있는 SVG(끌고 있는 블록 등)는 크기가 작아도 블록이라 그대로 둬요.
    if (svg.querySelector('.blockPath, .block, [blockId], [blockid]')) return;
    const size = svgIconSize(svg);
    if (!(size > 0 && size <= 64)) return;
    const nodes = [svg].concat(Array.from(svg.querySelectorAll('*')));
    // 원래 색(우리가 바꾸기 전 값) 모으기
    const items = [];
    let hasWhite = false, hasDark = false;
    nodes.forEach((node) => {
      const memo = svgTouched.get(node);
      SVG_ATTRS.forEach((attr) => {
        const cur = node.getAttribute(attr);
        if (!cur) return;
        const orig = memo && memo[attr] && memo[attr][1] === cur ? memo[attr][0] : cur;
        const c = parseColor(orig);
        if (!c || c.a === 0) return;
        const { s, l } = toHsl(c);
        if (l > 0.85) hasWhite = true;
        else if (l < 0.45 && s < 0.45) hasDark = true;
        items.push([node, attr, orig, c]);
      });
    });
    const kind = hasWhite ? 'lightButton' : hasDark ? 'darkGlyph' : null;
    if (!kind) return;
    items.forEach(([node, attr, orig, c]) => {
      const t = mapForKind(c, kind);
      if (!t) return;
      let memo = svgTouched.get(node);
      if (!memo) {
        memo = {};
        svgTouched.set(node, memo);
      }
      memo[attr] = [orig, t];
      if (node.getAttribute(attr) !== t) node.setAttribute(attr, t);
    });
  }

  function processInlineSvgs(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.tagName === 'svg') processInlineSvg(root);
    root.querySelectorAll('svg').forEach(processInlineSvg);
  }

  function restoreInlineSvgs() {
    svgTouched.forEach((memo, node) => {
      Object.keys(memo).forEach((attr) => {
        if (node.getAttribute(attr) === memo[attr][1]) node.setAttribute(attr, memo[attr][0]);
      });
    });
    svgTouched.clear();
  }

  // ---------- <img> 아이콘 (그림판 도구 등) ----------
  function processImg(img) {
    if (!img || img.tagName !== 'IMG') return;
    const cur = img.getAttribute('src');
    if (!cur || cur.indexOf('blob:') === 0) return;
    const rec = cur.indexOf('data:image/svg+xml') === 0 ? recoloredData(cur) : recoloredSvg(resolveUrl(cur, location.href));
    if (!rec) return;
    img.setAttribute('data-ee-src', cur);
    img.setAttribute('src', rec);
  }

  function processImgs(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.tagName === 'IMG') processImg(root);
    root.querySelectorAll('img').forEach(processImg);
  }

  function restoreImgs() {
    document.querySelectorAll('img[data-ee-src]').forEach((img) => {
      img.setAttribute('src', img.getAttribute('data-ee-src'));
      img.removeAttribute('data-ee-src');
    });
  }

  // 블록 카테고리 색처럼 원래 색을 지켜야 하는 선택자 (강조색으로 바꾸지 않음)
  const KEEP_ACCENT_SELECTOR = /category/i;

  // 규칙 하나의 색 관련 선언을 모두 !important로 다시 써요.
  // 바꿀 필요가 없는 색도 원래 값 그대로 다시 써야 해요. 안 그러면 우리가 !important로 바꾼
  // 덜 구체적인 규칙(예: 카테고리 기본 배경)이 원래 더 구체적이던 규칙(선택된 카테고리 색)을 이겨 버려요.
  function declarationsFor(style, selector, base, soft) {
    const out = [];
    // soft: 편집기 CSS의 변수 표. 있으면 !important 없이(원래 !important였던 것만 유지) 넣어서 직접 적힌 색이 이기게 해요.
    const imp = (prop) => (!soft || style.getPropertyPriority(prop) === 'important' ? '!important' : '');
    let bgAccent = null;
    const noAccent = !!selector && KEEP_ACCENT_SELECTOR.test(selector);
    for (let i = 0; i < SIMPLE_PROPS.length; i++) {
      const prop = SIMPLE_PROPS[i][0];
      const role = SIMPLE_PROPS[i][1];
      let v = style.getPropertyValue(prop);
      // 편집기 CSS는 색을 변수(var(--__se-...))로 적어요. 변수 값을 찾아 넣고 나서 바꿔요.
      // (background/border 줄임 속성에 변수가 있으면 낱개 속성은 비어 있어서 줄임 속성에서 색을 꺼내요)
      if (!v && soft && SHORTHAND_OF[prop]) {
        SHORTHAND_OF[prop].some((name) => {
          const sh = style.getPropertyValue(name);
          if (!sh || sh.indexOf('var(') < 0) return false;
          // border-color는 위/오른쪽/아래/왼쪽 순서로 색이 여러 개일 수 있어요.
          const colors = resolveVars(sh, soft).match(COLOR_TOKEN) || [];
          const side = ['top', 'right', 'bottom', 'left'].findIndex((d) => prop.indexOf(d) >= 0);
          const ORDER = [[0, 0, 0, 0], [0, 1, 0, 1], [0, 1, 2, 1], [0, 1, 2, 3]];
          const pick = name === 'border-color' && side >= 0 && colors.length > 1 ? colors[ORDER[Math.min(colors.length, 4) - 1][side]] : colors[0];
          if (pick) v = pick;
          return !!pick;
        });
      }
      if (!v) continue;
      if (soft && v.indexOf('var(') >= 0) v = resolveVars(v, soft);
      const skipFill = role === 'fill' && selector && SKIP_FILL_SELECTOR.test(selector);
      let t = skipFill ? null : transformValue(v, role, noAccent);
      if (prop === 'background-color') {
        const c = firstColor(v);
        bgAccent = c ? accentFor(c, noAccent) : null;
      }
      if (prop === 'color' && bgAccent && isLight(v)) {
        // 강조색 배경 위 글자: 강조색에 맞는 글자색(흰색 강조면 어두운 글자)
        t = fmt(bgAccent.on, 1);
      }
      out.push(prop + ':' + (t || v) + imp(prop));
    }
    let bi = style.getPropertyValue('background-image');
    if (soft && bi && bi.indexOf('var(') >= 0) bi = resolveVars(bi, soft);
    if (bi) {
      const before = bi;
      let v = bi;
      if (bi !== 'none' && LOGO_PATTERN.test(bi)) {
        v = LOGO_URL;
      } else if (bi !== 'none') {
        if (DARK_TEXT_LOGO_PATTERN.test(bi)) {
          out.push('filter:invert(1) hue-rotate(180deg) brightness(1.15)' + imp('filter'));
        }
        // 그라데이션 색 (주소가 섞여 있으면 파일 이름을 색으로 잘못 읽을 수 있어서 건너뜀)
        if (v.indexOf('gradient') >= 0 && v.indexOf('url(') < 0) {
          const t = transformValue(v, 'bg', noAccent);
          if (t) {
            v = t;
          }
        }
        // 먼저 상대 주소를 절대 주소로 바꾸고, 같은 사이트의 SVG 그림은 색을 바꾼 버전(blob: 주소)으로 바꿔요.
        v = absolutizeUrls(v, base);
        // 블록 카테고리 아이콘은 블록 색과 맞춰야 해서 그대로 둬요.
        if (!noAccent) {
          v = v.replace(/url\((["']?)([^"')]+)\1\)/g, (m, q, u) => {
            const recolored = recoloredSvg(resolveUrl(u, base)) || recoloredData(u, selector);
            return recolored ? 'url("' + recolored + '")' : m;
          });
        }
      }
      // 바뀌지 않은 data: 그림(엔트리 CSS 안에 박힌 큰 그림)은 다시 쓰지 않아요. 덮어쓰기 CSS가 몇 MB로 커져서요.
      const unchangedData = before.indexOf('data:') >= 0 && absolutizeUrls(before, base) === v;
      if (!unchangedData) out.push('background-image:' + v + imp('background-image'));
    }
    let bs = style.getPropertyValue('box-shadow');
    if (soft && bs && bs.indexOf('var(') >= 0) bs = resolveVars(bs, soft);
    if (bs) {
      const t = bs !== 'none' ? transformValue(bs, 'shadow', noAccent) : null;
      out.push('box-shadow:' + (t || bs) + imp('box-shadow'));
    }
    return out;
  }

  // ---------- 스타일시트 처리 ----------

  const sheetOverrides = new Map(); // CSSStyleSheet → <style>
  const dirty = new Set();
  let flushScheduled = false;

  // 줄임 속성 → 그 안의 색 속성
  const SHORTHAND_OF = {
    'background-color': ['background'],
    'border-top-color': ['border-color', 'border-top', 'border'],
    'border-right-color': ['border-color', 'border-right', 'border'],
    'border-bottom-color': ['border-color', 'border-bottom', 'border'],
    'border-left-color': ['border-color', 'border-left', 'border'],
    'outline-color': ['outline']
  };

  // var(--이름, 기본값)을 변수 표의 값으로 바꿔요(변수 안에 변수가 있어도 몇 번 더 풀어요). 못 풀면 그대로.
  const VAR_REF = /var\(\s*(--[\w-]+)\s*(?:,\s*([^()]*(?:\([^()]*\)[^()]*)*))?\)/g;
  function resolveVars(value, vars) {
    let out = value;
    for (let i = 0; i < 8 && out.indexOf('var(') >= 0; i++) {
      const next = out.replace(VAR_REF, (m, name, fb) => {
        const v = vars.get(name);
        return v !== undefined ? v : fb !== undefined ? fb.trim() : m;
      });
      if (next === out) break;
      out = next;
    }
    return out;
  }

  function collectVars(rules, vars) {
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      if (r.style) {
        for (let j = 0; j < r.style.length; j++) {
          const name = r.style[j];
          if (name.indexOf('--') === 0) vars.set(name, r.style.getPropertyValue(name).trim());
        }
      }
      if (r.cssRules && r.cssRules.length) collectVars(r.cssRules, vars);
    }
    return vars;
  }

  // 선택자 목록을 맨 바깥 쉼표로 나눠요(괄호 안 쉼표는 그대로).
  function splitSelectors(sel) {
    const parts = [];
    let depth = 0, quote = '', cur = '';
    for (let i = 0; i < sel.length; i++) {
      const ch = sel[i];
      if (quote) {
        if (ch === quote && sel[i - 1] !== '\\') quote = '';
      } else if (ch === '"' || ch === "'") quote = ch;
      else if (ch === '(' || ch === '[') depth++;
      else if (ch === ')' || ch === ']') depth--;
      else if (ch === ',' && depth === 0) {
        parts.push(cur.trim());
        cur = '';
        continue;
      }
      cur += ch;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }

  // soft 규칙은 !important가 없으니 원래 규칙보다 구체적이어야 이겨요 → 앞에 html.ee-dark를 붙여요.
  function boostSelector(sel) {
    return splitSelectors(sel)
      .map((p) => (/^(html|:root)\b/i.test(p) ? p.replace(/^(html|:root)/i, 'html.ee-dark') : 'html.ee-dark ' + p))
      .join(',');
  }

  function rulesToCss(rules, base, soft) {
    let css = '';
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      try {
        if (r.type === 1) {
          // CSSStyleRule
          const decls = declarationsFor(r.style, r.selectorText, base, soft);
          const sel = soft ? boostSelector(r.selectorText) : r.selectorText;
          if (decls.length) css += sel + '{' + decls.join(';') + '}';
          if (r.cssRules && r.cssRules.length) {
            const inner = rulesToCss(r.cssRules, base, soft);
            if (inner) css += sel + '{' + inner + '}';
          }
        } else if (r.type === 4 && r.media) {
          const inner = rulesToCss(r.cssRules, base, soft);
          if (inner) css += '@media ' + r.media.mediaText + '{' + inner + '}';
        } else if (r.type === 12 && r.conditionText) {
          const inner = rulesToCss(r.cssRules, base, soft);
          if (inner) css += '@supports ' + r.conditionText + '{' + inner + '}';
        } else if (r.cssRules && r.cssRules.length && !r.media) {
          // @layer, @container 등: 안쪽 규칙만 꺼내서 처리
          css += rulesToCss(r.cssRules, base, soft);
        }
      } catch (e) {
        // 규칙 하나가 이상해도 나머지는 계속
      }
    }
    return css;
  }

  function isOurSheet(sheet) {
    const n = sheet && sheet.ownerNode;
    return !!n && n.nodeType === 1 && n.hasAttribute(OURS);
  }

  // 다른 사이트 CSS(편집기) 사본: 주소 → CSSStyleSheet | null | PENDING
  const foreignCopies = new Map();
  const foreignSheetSet = new WeakSet();
  const foreignVars = new WeakMap(); // 사본 → 변수 표

  function foreignCopy(sheet) {
    const href = sheet.href;
    let host = '';
    try {
      host = new URL(href).hostname;
    } catch (e) {
      return null;
    }
    if (!FOREIGN_CSS_HOST.test(host)) return null;
    const hit = foreignCopies.get(href);
    if (hit !== undefined) return hit === PENDING ? null : hit;
    foreignCopies.set(href, PENDING);
    fetch(href, { credentials: 'omit' })
      .then((res) => (res.ok ? res.text() : null))
      .then((text) => {
        if (!text) throw new Error('no css');
        const copy = new CSSStyleSheet();
        foreignSheetSet.add(copy);
        copy.replaceSync(text.replace(/@import[^;]*;/g, ''));
        foreignVars.set(copy, collectVars(copy.cssRules, new Map()));
        foreignCopies.set(href, copy);
        markDirty(sheet);
      })
      .catch(() => foreignCopies.set(href, null));
    return null;
  }

  function processSheet(sheet) {
    if (!sheet || isOurSheet(sheet) || foreignSheetSet.has(sheet)) return;
    let rules;
    let soft = false;
    try {
      rules = sheet.cssRules;
    } catch (e) {
      // 다른 사이트 CSS: 글쓰기 편집기 것만 따로 받아서 처리해요(글꼴 CSS 등은 색이 없어서 괜찮아요).
      const copy = sheet.href ? foreignCopy(sheet) : null;
      if (!copy) return;
      rules = copy.cssRules;
      soft = foreignVars.get(copy) || new Map(); // soft = 변수 표(있으면 편집기 CSS)
    }
    if (!rules) return;
    let el = sheetOverrides.get(sheet);
    const css = sheet.disabled ? '' : rulesToCss(rules, sheet.href || location.href, soft);
    if (!css) {
      if (el) el.textContent = '';
      return;
    }
    if (!el) {
      el = document.createElement('style');
      el.setAttribute(OURS, 'sheet');
      sheetOverrides.set(sheet, el);
    }
    if (el.textContent !== css) el.textContent = css;
    placeOverride(el);
  }

  function styleRoot() {
    return document.head || document.documentElement;
  }

  function placeOverride(el) {
    const root = styleRoot();
    if (el.parentNode !== root) root.appendChild(el);
  }

  function markDirty(sheet) {
    if (!settings.darkMode || !sheet || isOurSheet(sheet) || foreignSheetSet.has(sheet)) return;
    dirty.add(sheet);
    if (flushScheduled) return;
    flushScheduled = true;
    // 엔트리가 같은 순간에 규칙을 여러 개 넣으므로, 한 번에 모아서 처리해요(그려지기 전에 끝나요).
    queueMicrotask(flush);
  }

  function flush() {
    flushScheduled = false;
    const list = Array.from(dirty);
    dirty.clear();
    list.forEach((sheet) => {
      try {
        processSheet(sheet);
      } catch (e) {
        console.warn(LOG, e);
      }
    });
  }

  function processAllSheets() {
    Array.from(document.styleSheets).forEach((s) => markDirty(s));
    // 없어진 시트의 덮어쓰기는 지워요.
    sheetOverrides.forEach((el, sheet) => {
      const node = sheet.ownerNode;
      if (!node || !node.isConnected) {
        el.remove();
        sheetOverrides.delete(sheet);
      }
    });
  }

  // 엔트리(emotion 등)가 규칙을 코드로 넣을 때 바로 알 수 있게 해요.
  function hookSheets() {
    const proto = CSSStyleSheet.prototype;
    const topSheet = (rule) => {
      let s = rule && rule.parentStyleSheet;
      while (s && s.ownerRule && s.ownerRule.parentStyleSheet) s = s.ownerRule.parentStyleSheet;
      return s;
    };
    ['insertRule', 'deleteRule', 'addRule', 'removeRule', 'replaceSync'].forEach((name) => {
      const orig = proto[name];
      if (typeof orig !== 'function') return;
      proto[name] = function () {
        const r = orig.apply(this, arguments);
        markDirty(this);
        return r;
      };
    });
    if (typeof proto.replace === 'function') {
      const origReplace = proto.replace;
      proto.replace = function () {
        const p = origReplace.apply(this, arguments);
        Promise.resolve(p).then(() => markDirty(this), () => {});
        return p;
      };
    }
    if (window.CSSGroupingRule) {
      const gp = CSSGroupingRule.prototype;
      ['insertRule', 'deleteRule'].forEach((name) => {
        const orig = gp[name];
        if (typeof orig !== 'function') return;
        gp[name] = function () {
          const r = orig.apply(this, arguments);
          markDirty(topSheet(this));
          return r;
        };
      });
    }
  }

  // ---------- 요소에 직접 적힌 style="" ----------

  const INLINE_PROPS = [
    ['background-color', 'bg'],
    ['color', 'text'],
    ['border-top-color', 'border'],
    ['border-right-color', 'border'],
    ['border-bottom-color', 'border'],
    ['border-left-color', 'border']
  ];
  const inlineDone = new WeakMap(); // 요소 → { prop: [원래 값, 우리가 넣은 값] }
  const inlineTouched = new Set();
  // 색 고르기 칸(팔레트 등)은 그 색 자체가 내용이라 그대로 둬요.
  const COLOR_VALUE_AREA = '[class*="olor_picker"], [class*="olorPicker"], [class*="olorSwatch"], [class*="palette"], [class*="Palette"], [class*="swatch"], [class*="Swatch"]';

  function processInline(el) {
    if (!(el instanceof HTMLElement) || !el.style || !el.style.length) return;
    if (el.closest('svg')) return;
    // 글쓰기 편집기 안의 글(사용자가 고른 색)은 바꾸면 저장되는 글에 섞여 들어가요.
    if (el.isContentEditable) return;
    if (el.closest(COLOR_VALUE_AREA)) {
      // 색 칸은 색을 바꾸지 않고, 우리 !important 규칙(버튼 기본 배경 등)에 가려지지 않게만 해요.
      ['background-color', 'color'].forEach((prop) => {
        const cur = el.style.getPropertyValue(prop);
        if (cur && el.style.getPropertyPriority(prop) !== 'important') el.style.setProperty(prop, cur, 'important');
      });
      return;
    }
    let memo = inlineDone.get(el);
    // 직접 적힌 색은 원래 스타일시트보다 우선이었어요. 우리 덮어쓰기(!important)에 지지 않게
    // 바꿀 필요가 없는 색도 !important로 다시 적어요.
    INLINE_PROPS.forEach(([prop, role]) => {
      const cur = el.style.getPropertyValue(prop);
      if (!cur) return;
      const important = el.style.getPropertyPriority(prop) === 'important';
      if (memo && memo[prop] && memo[prop][1] === cur && important) return; // 우리가 넣은 값 그대로
      const t = transformValue(cur, role) || cur;
      if (!memo) {
        memo = {};
        inlineDone.set(el, memo);
      }
      memo[prop] = [cur, t, important];
      el.style.setProperty(prop, t, 'important');
      inlineTouched.add(el);
    });
    // 직접 적힌 그림(프로필 사진, 작품 썸네일 등)이 우리 !important 규칙(기본 프로필 그림 등)에
    // 가려지지 않게, 같은 그림을 !important로 다시 적어요.
    const bi = el.style.getPropertyValue('background-image');
    if (bi && el.style.getPropertyPriority('background-image') !== 'important') {
      if (!memo) {
        memo = {};
        inlineDone.set(el, memo);
      }
      memo['background-image'] = [bi, bi, false];
      el.style.setProperty('background-image', bi, 'important');
      inlineTouched.add(el);
    }
  }

  function processInlineTree(root) {
    if (!root || root.nodeType !== 1) return;
    if (root.hasAttribute('style')) processInline(root);
    if (root.querySelectorAll) root.querySelectorAll('[style]').forEach(processInline);
  }

  function restoreInline() {
    inlineTouched.forEach((el) => {
      const memo = inlineDone.get(el);
      if (!memo) return;
      Object.keys(memo).forEach((prop) => {
        const [orig, ours, wasImportant] = memo[prop];
        if (el.style.getPropertyValue(prop) === ours) el.style.setProperty(prop, orig, wasImportant ? 'important' : '');
      });
      inlineDone.delete(el);
    });
    inlineTouched.clear();
  }

  // ---------- 기본 스타일 ----------

  function baseCss() {
    const ac = greenAccent() || blueAccent();
    const sel = ac ? fmt(ac.base, 0.45) : 'rgba(50, 210, 125, 0.4)';
    // 블록 꾸러미의 "신호 만들기" 같은 버튼(원래 흰 바탕 + 파란 글자)
    const blue = blueAccent() || ACCENTS.blue;
    const btnText = fmt(blue.text, 1);
    const btnLine = fmt(blue.base, 1);
    return `
      html { background-color: ${PAGE_BG} !important; color-scheme: dark; scrollbar-color: #454a55 #1c1f25; }
      body { color: #e6e8ec; }
      ::selection { background: ${sel}; }
      input, textarea, select { color-scheme: dark; }
      html.ee-dark .block.basicButtonView > g > path,
      html.ee-dark .block.basicButtonView path.blockPath { fill: #262a31 !important; stroke: ${btnLine} !important; }
      html.ee-dark .block.basicButtonView text,
      html.ee-dark .block.basicButtonView tspan { fill: ${btnText} !important; }
      ${editorFlipCss()}
    `;
  }

  // 글쓰기 편집기 안 글: 검은 글씨/흰 글씨(배경 강조 포함)만 화면에서 서로 바꿔 보여 줘요. 다른 색은 그대로.
  function editorFlipCss() {
    const light = transformColor({ r: 0, g: 0, b: 0, a: 1 }, 'text');
    const dark = transformColor({ r: 255, g: 255, b: 255, a: 1 }, 'bg');
    const sel = (prop, values) => {
      const out = [];
      values.forEach((v) => {
        [prop + ': ' + v, prop + ':' + v].forEach((d) => {
          out.push('[style^="' + d + '" i]', '[style*="; ' + d + '" i]', '[style*=";' + d + '" i]');
        });
      });
      return 'html.ee-dark ' + EDITOR_CONTENT + ' :is(' + out.join(',') + ')';
    };
    const BLACK = ['rgb(0, 0, 0)', '#000000', '#000;', 'black;'];
    const WHITE = ['rgb(255, 255, 255)', '#ffffff', '#fff;', 'white;'];
    return [
      sel('color', BLACK) + '{color:' + light + '!important}',
      sel('color', WHITE) + '{color:' + dark + '!important}',
      sel('background-color', BLACK) + '{background-color:' + light + '!important}',
      sel('background-color', WHITE) + '{background-color:' + dark + '!important}'
    ].join('\n');
  }

  let baseEl = null;
  function applyBase() {
    if (!baseEl) {
      baseEl = document.createElement('style');
      baseEl.setAttribute(OURS, 'base');
    }
    baseEl.textContent = baseCss();
    const root = styleRoot();
    if (baseEl.parentNode !== root) root.appendChild(baseEl);
  }

  // ---------- 켜기 / 끄기 ----------

  let observer = null;
  let active = false;

  function onMutations(list) {
    for (let i = 0; i < list.length; i++) {
      const m = list[i];
      if (m.type === 'attributes') {
        if (m.attributeName === 'style') processInline(m.target);
        else if (m.target.tagName === 'image') processSvgImage(m.target);
        else if (m.target.tagName === 'IMG') processImg(m.target);
        else if (m.target instanceof SVGElement && m.attributeName !== 'href') {
          const top = m.target.tagName === 'svg' && !m.target.ownerSVGElement ? m.target : m.target.closest('svg');
          if (top) processInlineSvg(top.ownerSVGElement ? top.ownerSVGElement : top);
        }
        continue;
      }
      m.addedNodes.forEach((n) => {
        if (n.nodeType !== 1) return;
        if (n.hasAttribute && n.hasAttribute(OURS)) return;
        if (n.tagName === 'STYLE') {
          if (n.sheet) markDirty(n.sheet);
        } else if (n.tagName === 'LINK') {
          if (n.sheet) markDirty(n.sheet);
          n.addEventListener('load', () => markDirty(n.sheet), { once: true });
        } else {
          processInlineTree(n);
          processSvgImages(n);
          processImgs(n);
          processInlineSvgs(n);
          if (n instanceof SVGElement && n.tagName !== 'svg') {
            const top = n.closest('svg');
            if (top) processInlineSvg(top);
          }
          n.querySelectorAll && n.querySelectorAll('style, link[rel~="stylesheet"]').forEach((s) => s.sheet && markDirty(s.sheet));
        }
      });
      if (m.removedNodes.length) {
        m.removedNodes.forEach((n) => {
          if (n.nodeType === 1 && (n.tagName === 'STYLE' || n.tagName === 'LINK')) {
            sheetOverrides.forEach((el, sheet) => {
              if (sheet.ownerNode === n) {
                el.remove();
                sheetOverrides.delete(sheet);
              }
            });
          }
        });
      }
    }
    // 기본 스타일이 지워졌으면(페이지가 head를 갈아 끼운 경우 등) 다시 넣어요.
    if (active && baseEl && !baseEl.isConnected) applyBase();
  }

  function enable() {
    if (active) return;
    active = true;
    document.documentElement.classList.add('ee-dark');
    applyBase();
    processAllSheets();
    if (document.body) processInlineTree(document.body);
    processSvgImages(document);
    processImgs(document);
    processInlineSvgs(document);
    observer = new MutationObserver(onMutations);
    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['style', 'href', 'src', 'fill', 'stroke']
    });
  }

  function disable() {
    if (!active) return;
    active = false;
    if (observer) observer.disconnect();
    observer = null;
    document.documentElement.classList.remove('ee-dark');
    if (baseEl) baseEl.remove();
    sheetOverrides.forEach((el) => el.remove());
    sheetOverrides.clear();
    dirty.clear();
    restoreInline();
    restoreSvgImages();
    restoreImgs();
    restoreInlineSvgs();
  }

  function refresh() {
    colorCache.clear();
    assetCache.clear();
    if (!settings.darkMode) {
      disable();
      return;
    }
    if (!active) {
      enable();
      return;
    }
    // 강조색이 바뀐 경우: 전부 다시 계산
    restoreInline();
    applyBase();
    processAllSheets();
    if (document.body) processInlineTree(document.body);
  }

  // ---------- 설정 ----------

  function saveCache() {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({ darkMode: settings.darkMode, accentColor: settings.accentColor, blueColor: settings.blueColor }));
    } catch (e) {
      // 무시
    }
  }

  window.addEventListener('easy-entry:settings', (e) => {
    let next;
    try {
      next = JSON.parse(e.detail);
    } catch (err) {
      return;
    }
    if (!next || typeof next !== 'object') return;
    const key = () => settings.darkMode + '|' + settings.accentColor + '|' + settings.blueColor;
    const before = key();
    if (typeof next.darkMode === 'boolean') settings.darkMode = next.darkMode;
    if (typeof next.accentColor === 'string' && next.accentColor in ACCENTS) settings.accentColor = next.accentColor;
    if (typeof next.blueColor === 'string' && next.blueColor in ACCENTS) settings.blueColor = next.blueColor;
    saveCache();
    if (before !== key()) refresh();
  });

  // ---------- 시작 ----------

  hookSheets();
  if (settings.darkMode) enable();
  // 작품 실행 화면, 글쓰기 편집기는 페이지 안의 iframe이에요. 엔트리가 iframe 문서를 새로 써 넣으면
  // (document.open) 우리 스타일과 감시가 사라지므로, 문서가 바뀌었는지 가끔 확인해서 다시 켜요.
  if (window !== window.top) {
    let root = document.documentElement;
    setInterval(() => {
      if (document.documentElement === root) return;
      root = document.documentElement;
      if (!active) return;
      if (observer) observer.disconnect();
      observer = null;
      active = false;
      sheetOverrides.clear();
      dirty.clear();
      baseEl = null;
      enable();
    }, 500);
  }
  // 처음 로드 중에 들어온 CSS 파일(link)이 다 읽히면 한 번 더 확인해요.
  document.addEventListener('DOMContentLoaded', () => active && processAllSheets());
  window.addEventListener('load', () => active && processAllSheets());
  window.dispatchEvent(new CustomEvent('easy-entry:request-settings'));
})();
