// 배경음악: 엔트리 탭이 열려 있다고 확장 프로그램 본체(background.js)에 알려요.
// 음악은 확장 프로그램 안의 보이지 않는 페이지(offscreen)에서 틀어서, 엔트리 페이지를 옮겨 다녀도 끊기지 않아요.
(() => {
  'use strict';

  if (window.top !== window) return;

  function send(action) {
    try {
      chrome.runtime.sendMessage({ type: 'ee-bgm', action }, () => void chrome.runtime.lastError);
    } catch (e) {
      // 확장 프로그램을 다시 불러온 직후에는 연결이 끊겨요. 새로고침하면 다시 돼요.
    }
  }

  send('hello');
  // 뒤로 가기 캐시에서 돌아왔을 때
  window.addEventListener('pageshow', (e) => {
    if (e.persisted) send('hello');
  });
  window.addEventListener('pagehide', () => send('bye'));
})();
