// 확장 프로그램 쪽(격리된 세계)에서 실행됩니다.
// 페이지 쪽 스크립트는 chrome.storage를 못 쓰기 때문에, 설정을 이벤트로 전달해 줍니다.
(() => {
  'use strict';

  function sendSettings() {
    try {
      chrome.storage.sync.get(EASY_ENTRY_DEFAULTS, (settings) => {
        if (chrome.runtime.lastError || !settings) return;
        // 세계 사이에서는 객체가 제대로 전달되지 않을 수 있어 문자열로 보냅니다.
        window.dispatchEvent(
          new CustomEvent('easy-entry:settings', { detail: JSON.stringify(settings) })
        );
      });
    } catch (e) {
      // 확장 프로그램이 다시 로드되면 이 스크립트는 연결이 끊깁니다. 새로고침하면 다시 동작해요.
    }
  }

  window.addEventListener('easy-entry:request-settings', sendSettings);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync') sendSettings();
    });
  } catch (e) {
    // 위와 같은 이유로 무시합니다.
  }

  sendSettings();
})();
