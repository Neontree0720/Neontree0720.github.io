// 모양 그림판(entry-paint) 공용 도구 모음. 그림판 기능(따라그리기, 구부리기)이 함께 씁니다.
// - 그림판/캔버스/paper.js 찾기, 좌표 변환
// - 왼쪽 도구 막대에 우리 도구 버튼 넣기 (선택 표시, 엔트리 도구와 서로 바뀌기)
// - 그림판 왼쪽 아래 패널 자리
// - 엔트리 그림판 되돌리기 기록 남기기
(() => {
  'use strict';

  const EE = window.__easyEntry;
  if (!EE || EE.paint) return;

  const OUR_PREFIX = 'easy-entry-'; // 그림판 안에 넣는 우리 물건 이름 앞부분
  const ACTIVE_BORDER_FALLBACK = 'rgb(79, 128, 255)';

  // ---------- 그림판 찾기 ----------

  function getPaint() {
    const E = EE.getEntry();
    const painter = E && E.playground && E.playground.painter;
    const ep = painter && painter.entryPaint;
    let scope = null;
    try {
      scope = ep ? ep.paper : null;
    } catch (e) {
      return null;
    }
    const view = scope && scope.view;
    const canvas = view && view.element;
    const root = document.getElementById('entryPainter');
    if (!view || !canvas || !root || !canvas.isConnected || !root.contains(canvas)) return null;
    if (!canvas.parentElement || typeof view.projectToView !== 'function') return null;
    return { painter, ep, scope, view, canvas, root };
  }

  function isVisible(p) {
    return !!p && p.root.offsetParent !== null && p.canvas.clientWidth > 0 && p.canvas.clientHeight > 0;
  }

  // 'VECTOR' 또는 'BITMAP' (모르면 null)
  function getMode(p) {
    try {
      const m = p.ep.mode;
      return m === 'VECTOR' || m === 'BITMAP' ? m : null;
    } catch (e) {
      return null;
    }
  }

  function toView(p, x, y) {
    return p.view.projectToView(new p.scope.Point(x, y));
  }

  function clientToProject(p, clientX, clientY) {
    const r = p.canvas.getBoundingClientRect();
    return p.view.viewToProject(new p.scope.Point(clientX - r.left, clientY - r.top));
  }

  function redraw(p) {
    try {
      if (typeof p.view.requestUpdate === 'function') p.view.requestUpdate();
      else p.view.update();
    } catch (e) {
      // 무시: 다음 화면 갱신 때 그려져요.
    }
  }

  function isOurs(item) {
    return !!item && typeof item.name === 'string' && item.name.indexOf(OUR_PREFIX) === 0;
  }

  function boundsWithoutOurs(layer) {
    let rect = null;
    (layer.children || []).forEach((child) => {
      if (isOurs(child)) return;
      const b = child.bounds;
      if (!b || !(b.width > 0) || !(b.height > 0)) return;
      rect = rect ? rect.unite(b) : b.clone();
    });
    return rect;
  }

  // 바둑판(그림 영역) 층: 엔트리가 잠가 둔 레이어/그룹 중 가장 큰 것. { layer, rect } 또는 null
  function findArtboard(p) {
    let best = null;
    let bestArea = 0;
    const visit = (item, depth) => {
      if (!item || depth > 4 || isOurs(item)) return;
      if (item.className !== 'Layer' && item.className !== 'Group') return;
      if (item.locked && item.children && item.children.length) {
        const rect = boundsWithoutOurs(item);
        if (rect && rect.width >= 50 && rect.height >= 50 && rect.width * rect.height > bestArea) {
          best = { layer: item, rect };
          bestArea = rect.width * rect.height;
        }
      }
      (item.children || []).forEach((c) => visit(c, depth + 1));
    };
    try {
      p.scope.project.layers.forEach((layer) => visit(layer, 0));
    } catch (e) {
      return null;
    }
    return best;
  }

  // 그림이 들어 있는 층: 잠긴 층 밖에 있는 가장 깊은 레이어.
  function findPaintLayer(p) {
    let best = null;
    let bestDepth = -1;
    const visit = (item, depth, lockedAbove) => {
      if (!item || depth > 5 || isOurs(item)) return;
      if (item.className !== 'Layer' && item.className !== 'Group') return;
      const locked = lockedAbove || !!item.locked;
      if (item.className === 'Layer' && !locked && depth > bestDepth) {
        best = item;
        bestDepth = depth;
      }
      (item.children || []).forEach((c) => visit(c, depth + 1, locked));
    };
    try {
      p.scope.project.layers.forEach((layer) => visit(layer, 0, false));
    } catch (e) {
      return null;
    }
    return best;
  }

  // 엔트리가 그려 둔 편집 안내선(선택 상자, 형태 도구의 점·핸들 등)을 지웁니다.
  // 도형을 코드로 바꾸면 안내선이 옛 모양으로 남아 보이기 때문이에요. 엔트리가 다음 동작 때 다시 그려요.
  // 안내선 층 = 바둑판 층과 같은 부모 아래에 있으면서, 바둑판 층도 그림 층도 아닌 레이어.
  function clearGuides(p) {
    const art = findArtboard(p);
    const paint = findPaintLayer(p);
    const parent = art && art.layer && art.layer.parent;
    if (!parent || !paint) return 0;
    let removed = 0;
    (parent.children || []).slice().forEach((layer) => {
      if (layer === art.layer || layer.className !== 'Layer' || layer.locked) return;
      if (layer === paint || paint.isDescendant(layer)) return;
      (layer.children || []).slice().forEach((child) => {
        if (isOurs(child)) return;
        try {
          child.remove();
          removed++;
        } catch (e) {
          // 무시
        }
      });
    });
    if (removed) redraw(p);
    return removed;
  }

  // ---------- 엔트리 그림판 상태(redux store) ----------

  let cachedStore = null;

  // 그림판 React 화면에서 store를 찾습니다. (선택된 도형, 현재 도구를 정확히 알 수 있어요)
  function getStore(p) {
    if (cachedStore) {
      try {
        const st = cachedStore.getState();
        if (st && st.paint && st.tool) return cachedStore;
      } catch (e) {
        // 다시 찾기
      }
      cachedStore = null;
    }
    const nodes = [p.root].concat(Array.from(p.root.querySelectorAll('*')).slice(0, 300));
    for (let i = 0; i < nodes.length; i++) {
      const n = nodes[i];
      const key = Object.keys(n).find((k) => k.indexOf('__reactFiber$') === 0 || k.indexOf('__reactInternalInstance$') === 0);
      if (!key) continue;
      let f = n[key];
      for (let depth = 0; f && depth < 80; depth++, f = f.return) {
        const props = f.memoizedProps;
        const cands = [props && props.store, props && props.value && props.value.store];
        for (let j = 0; j < cands.length; j++) {
          const s = cands[j];
          if (s && typeof s.getState === 'function') {
            try {
              const st = s.getState();
              if (st && st.paint && st.tool) {
                cachedStore = s;
                return s;
              }
            } catch (e) {
              // 다음 후보
            }
          }
        }
      }
    }
    return null;
  }

  // 엔트리에서 지금 선택된 그림 조각들(그림 층 바로 아래 항목). 모르면 null, 없으면 [].
  function getSelectedItems(p) {
    const store = getStore(p);
    const paint = findPaintLayer(p);
    if (!store || !paint) return null;
    let list;
    try {
      list = store.getState().paint.selectedItems;
    } catch (e) {
      return null;
    }
    if (!Array.isArray(list)) return null;
    const out = [];
    list.forEach((item) => {
      let it = item;
      while (it && it.parent && it.parent !== paint) it = it.parent;
      if (it && it.parent === paint && out.indexOf(it) < 0) out.push(it);
    });
    return out;
  }

  // ---------- 되돌리기 기록 ----------

  function findVectorSelectTool(p) {
    const list = (p.scope && p.scope.tools) || [];
    return list.find((t) => t && t.MY_MODE && t.MY_MODE.toolMode === 'SELECT' && t.MY_MODE.graphicsMode === 'VECTOR') || null;
  }

  function firstCallback(tool, type) {
    const cbs = tool && tool._callbacks && tool._callbacks[type];
    return Array.isArray(cbs) && typeof cbs[0] === 'function' ? cbs[0] : null;
  }

  // 코드로 바꾼 그림을 엔트리 그림판 되돌리기 기록에 남깁니다(벡터 모드).
  // 엔트리의 Ctrl+A 처리 코드가 "전체 선택 + 기록 저장"을 하므로 그걸 그대로 부릅니다.
  // reselect: 기록 뒤 다시 선택해 둘 아이템들(없으면 전체 선택 상태로 둠).
  // 성공하면 true.
  function saveSnapshot(p, reselect) {
    const tool = findVectorSelectTool(p);
    const keydown = firstCallback(tool, 'keydown');
    if (!keydown) return false;
    holdToolChange(600);
    try {
      keydown({
        event: { target: document.body, preventDefault() {}, stopPropagation() {} },
        modifiers: { control: true, shift: false, alt: false, meta: false },
        key: 'a'
      });
    } catch (e) {
      EE.warn('그림판 기록을 남기지 못했어요:', e);
      return false;
    }
    if (Array.isArray(reselect) && reselect.length) {
      const mouseup = firstCallback(tool, 'mouseup');
      if (mouseup) {
        reselect.forEach((item, i) => {
          try {
            if (!item || !item.parent) return;
            tool.isMoved = false;
            mouseup({ item, point: item.position, modifiers: { shift: i > 0 } });
          } catch (e) {
            // 선택만 못 바꾼 것이라 무시해요.
          }
        });
      }
    }
    redraw(p);
    return true;
  }

  // ---------- 스타일 ----------

  function injectStyle() {
    if (document.getElementById('ee-paint-kit-style')) return;
    const style = document.createElement('style');
    style.id = 'ee-paint-kit-style';
    style.textContent = `
      .ee-panel-host { position: absolute; left: 10px; right: 10px; bottom: 10px; z-index: 5;
        display: flex; flex-direction: column; align-items: flex-start; gap: 6px; pointer-events: none; }
      .ee-panel-host > .ee-panel { position: static !important; left: auto !important; bottom: auto !important; }
      .ee-panel { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; padding: 6px 8px; pointer-events: auto;
        max-width: 100%; box-sizing: border-box;
        background: #fff; border: 1px solid #e2e2e2; border-radius: 6px;
        box-shadow: 0 2px 6px rgba(0,0,0,.12); color: #2c313d;
        font: 12px/1.2 "NanumGothic", "Noto Sans KR", sans-serif; white-space: nowrap; user-select: none; }
      .ee-panel[hidden] { display: none; }
      .ee-panel button { height: 26px; padding: 0 8px; border: 1px solid #d6d9df; border-radius: 4px;
        background: #fff; color: #2c313d; font: inherit; cursor: pointer; }
      .ee-panel button:hover { border-color: #4f80ff; color: #4f80ff; }
      .ee-panel button.ee-primary { background: #4f80ff; border-color: #4f80ff; color: #fff; }
      .ee-panel button.ee-primary:hover { background: #3c6ef0; color: #fff; }
      .ee-panel input[type="range"] { -webkit-appearance: auto !important; appearance: auto !important;
        width: 90px; height: 16px; margin: 0; padding: 0; border: 0; background: transparent; accent-color: #4f80ff; }
      .ee-panel .ee-pct { min-width: 32px; text-align: right; color: #4f80ff; font-weight: bold; }
      .ee-panel .ee-muted { color: #8a8f99; }
      .ee-panel .ee-msg { color: #e24a4a; }
      .ee-panel .ee-msg:empty { display: none; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function el(tag, cls, attrs) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (attrs) Object.keys(attrs).forEach((k) => node.setAttribute(k, attrs[k]));
    return node;
  }

  function stopAll(node, types) {
    types.forEach((type) => node.addEventListener(type, (e) => e.stopPropagation()));
  }

  // 패널에서 누른 키(Delete, 방향키 등)나 클릭이 엔트리로 가지 않게 막습니다.
  function isolatePanel(panel) {
    stopAll(panel, ['keydown', 'keyup', 'keypress', 'pointerdown', 'mousedown', 'mouseup', 'click', 'dblclick', 'wheel', 'touchstart']);
  }

  // ---------- 패널 자리 (그림판 왼쪽 아래) ----------

  let panelHost = null;

  function ensurePanelHost(p) {
    injectStyle();
    if (!panelHost) panelHost = el('div', 'ee-panel-host');
    const area = p.canvas.closest('.canvas_area') || p.canvas.parentElement.parentElement || p.canvas.parentElement;
    if (panelHost.parentElement !== area) area.appendChild(panelHost);
    return panelHost;
  }

  // 캔버스 바로 위에 덮는 층을 제자리에 두고 크기를 캔버스와 맞춥니다.
  function placeOverCanvas(p, layer, order) {
    const c = p.canvas;
    const host = c.parentElement;
    if (layer.parentElement !== host) host.appendChild(layer);
    layer.style.zIndex = String(order || 1);
    const s = layer.style;
    const left = c.offsetLeft + 'px';
    const top = c.offsetTop + 'px';
    const width = c.clientWidth + 'px';
    const height = c.clientHeight + 'px';
    if (s.left !== left) s.left = left;
    if (s.top !== top) s.top = top;
    if (s.width !== width) s.width = width;
    if (s.height !== height) s.height = height;
  }

  // ---------- 도구 버튼 ----------

  const tools = []; // 등록된 도구 정의
  let activeTool = null;
  let muted = null; // { el, prevBorder, img, prevFilter } 우리 도구를 쓰는 동안 선택 표시를 꺼 둔 엔트리 도구
  let observer = null;
  let observedSide = null;
  let holdUntil = 0; // 이 시각 전까지는 엔트리 도구가 바뀌어도 우리 도구를 끄지 않음(기록 저장 중)

  function holdToolChange(ms) {
    holdUntil = Math.max(holdUntil, performance.now() + ms);
  }

  function iconUrl(def, active) {
    const svg = def.iconSvg(active ? '#4f80ff' : '#979797');
    return 'data:image/svg+xml,' + encodeURIComponent(svg);
  }

  function entryWrappers(side) {
    return Array.from(side.children).filter(
      (n) => n.classList.contains('ToolButtonWrapper') && !n.classList.contains('ee-tool')
    );
  }

  // 선택된 도구만 클래스가 달라요. 가장 많은 클래스 = 보통 도구, 나머지 하나 = 선택된 도구.
  function classifyTools(side) {
    const list = entryWrappers(side);
    const counts = new Map();
    list.forEach((n) => counts.set(n.className, (counts.get(n.className) || 0) + 1));
    if (!list.length) return { normal: null, selected: null };
    if (counts.size < 2) return { normal: list[0], selected: null };
    const normalClass = Array.from(counts.entries()).sort((a, b) => b[1] - a[1])[0][0];
    return {
      normal: list.find((n) => n.className === normalClass) || null,
      selected: list.find((n) => n.className !== normalClass) || null
    };
  }

  function findSide(p) {
    const first = p.root.querySelector('.ToolButtonWrapper:not(.ee-tool)');
    return first ? first.parentElement : null;
  }

  function buildButton(def, template) {
    const btn = template.cloneNode(true);
    btn.classList.add('ee-tool', 'ee-tool-' + def.id);
    btn.removeAttribute('id');
    btn.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
    btn.style.borderColor = '';
    const icon = btn.querySelector('img');
    if (icon) {
      icon.src = iconUrl(def, false);
      icon.alt = def.label;
      icon.style.filter = '';
    }
    // 글자(라벨)를 바꿉니다.
    let replaced = false;
    const walker = document.createTreeWalker(btn, NodeFilter.SHOW_TEXT);
    const texts = [];
    while (walker.nextNode()) texts.push(walker.currentNode);
    texts.forEach((t) => {
      if (!t.nodeValue.trim()) return;
      t.nodeValue = replaced ? '' : def.label;
      replaced = true;
    });
    btn.title = def.title || def.label;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (activeTool === def) deactivate();
      else activate(def);
    });
    stopAll(btn, ['pointerdown', 'mousedown', 'mouseup']);
    return btn;
  }

  function setButtonActive(def, on) {
    if (!def.btn) return;
    def.btn.style.borderColor = on ? def.activeBorder || ACTIVE_BORDER_FALLBACK : '';
    const icon = def.btn.querySelector('img');
    const url = iconUrl(def, on);
    if (icon && icon.getAttribute('src') !== url) icon.src = url;
  }

  function unmute() {
    if (!muted) return;
    muted.el.style.borderColor = muted.prevBorder;
    if (muted.img) muted.img.style.filter = muted.prevFilter;
    muted = null;
  }

  function muteSelected(side) {
    const t = classifyTools(side);
    if (!t.selected || !t.normal) return ACTIVE_BORDER_FALLBACK;
    const border = getComputedStyle(t.selected).borderColor || ACTIVE_BORDER_FALLBACK;
    const img = t.selected.querySelector('img');
    muted = {
      el: t.selected,
      prevBorder: t.selected.style.borderColor,
      img,
      prevFilter: img ? img.style.filter : ''
    };
    t.selected.style.borderColor = getComputedStyle(t.normal).borderColor;
    if (img) img.style.filter = 'grayscale(1)';
    return border;
  }

  function activate(def) {
    if (activeTool === def) return;
    if (activeTool) deactivate();
    if (!def.btn || !def.btn.parentElement) return;
    def.activeBorder = muteSelected(def.btn.parentElement);
    activeTool = def;
    setButtonActive(def, true);
    try {
      def.onActivate && def.onActivate();
    } catch (e) {
      EE.warn(def.id, '도구를 켜다가 오류가 났어요:', e);
    }
  }

  function deactivate() {
    const def = activeTool;
    if (!def) return;
    activeTool = null;
    unmute();
    setButtonActive(def, false);
    try {
      def.onDeactivate && def.onDeactivate();
    } catch (e) {
      EE.warn(def.id, '도구를 끄다가 오류가 났어요:', e);
    }
  }

  // 엔트리 쪽에서 다른 도구가 골라지면(클릭, 단축키) 우리 도구를 끕니다.
  function watchSide(side) {
    if (observedSide === side) return;
    if (observer) observer.disconnect();
    observedSide = side;
    observer = new MutationObserver(() => {
      if (!activeTool) return;
      const t = classifyTools(side);
      if (t.selected === (muted && muted.el)) return;
      if (performance.now() < holdUntil) {
        // 우리가 기록을 남기느라 엔트리 도구가 바뀐 경우: 끄지 않고 새 도구의 선택 표시만 다시 꺼 둡니다.
        unmute();
        muteSelected(side);
        return;
      }
      deactivate();
    });
    observer.observe(side, { attributes: true, attributeFilter: ['class'], subtree: true });
    side.addEventListener(
      'pointerdown',
      (e) => {
        const wrapper = e.target && e.target.closest ? e.target.closest('.ToolButtonWrapper') : null;
        if (activeTool && wrapper && !wrapper.classList.contains('ee-tool')) deactivate();
      },
      true
    );
  }

  document.addEventListener(
    'keydown',
    (e) => {
      if (activeTool && e.key === 'Escape') deactivate();
    },
    true
  );

  function ensureButtons(p) {
    const side = findSide(p);
    if (!side) return;
    const t = classifyTools(side);
    const template = t.normal || t.selected;
    if (!template) return;

    const enabled = tools.filter((def) => def.isEnabled());
    tools.forEach((def) => {
      if (enabled.indexOf(def) >= 0) return;
      if (activeTool === def) deactivate();
      if (def.btn) def.btn.remove();
      def.btn = null;
      def.btnBase = '';
    });

    // 엔트리 첫 도구 앞에 등록 순서대로 넣습니다.
    let anchor = entryWrappers(side)[0];
    for (let i = enabled.length - 1; i >= 0; i--) {
      const def = enabled[i];
      if (!def.btn || def.btnBase !== template.className) {
        if (activeTool === def) deactivate();
        if (def.btn) def.btn.remove();
        def.btn = buildButton(def, template);
        def.btnBase = template.className;
      }
      if (def.btn.parentElement !== side || def.btn.nextElementSibling !== anchor) {
        if (activeTool === def) deactivate();
        side.insertBefore(def.btn, anchor);
      }
      anchor = def.btn;
    }
    watchSide(side);
  }

  // ---------- 매 프레임 ----------

  const tickers = [];
  let lastEnsure = 0;
  let warned = false;

  function frame(now) {
    try {
      const p0 = getPaint();
      const p = p0 && isVisible(p0) ? p0 : null;
      if (!p && activeTool) deactivate();
      if (p && now - lastEnsure > 200) {
        lastEnsure = now;
        ensureButtons(p);
      }
      tickers.forEach((fn) => {
        try {
          fn(p, now);
        } catch (e) {
          if (!fn.__eeWarned) {
            fn.__eeWarned = true;
            EE.warn('그림판 기능에서 오류가 났어요:', e);
          }
        }
      });
    } catch (e) {
      if (!warned) {
        warned = true;
        EE.warn('그림판 도구에서 오류가 났어요:', e);
      }
    }
    requestAnimationFrame(frame);
  }

  EE.paint = {
    OUR_PREFIX,
    isOurs,
    getPaint,
    isVisible,
    getMode,
    toView,
    clientToProject,
    redraw,
    findArtboard,
    findPaintLayer,
    clearGuides,
    getStore,
    getSelectedItems,
    saveSnapshot,
    injectStyle,
    el,
    stopAll,
    isolatePanel,
    ensurePanelHost,
    placeOverCanvas,
    // 도구 등록: { id, label, title, order, iconSvg(color), isEnabled(), onActivate(), onDeactivate() }
    registerTool(def) {
      def.btn = null;
      def.btnBase = '';
      tools.push(def);
      tools.sort((a, b) => (a.order || 0) - (b.order || 0));
      return {
        isActive: () => activeTool === def,
        deactivate: () => {
          if (activeTool === def) deactivate();
        }
      };
    },
    // 매 프레임 불림. p는 그림판이 화면에 보일 때만 있고, 아니면 null.
    onFrame(fn) {
      if (typeof fn === 'function') tickers.push(fn);
    }
  };

  requestAnimationFrame(frame);
})();
