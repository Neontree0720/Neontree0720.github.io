// 설정 기본값. bridge.js와 popup.js가 함께 씁니다.
// 페이지 쪽(core.js)에도 같은 값이 들어 있으니, 바꿀 때는 두 곳을 함께 바꿔 주세요.
var EASY_ENTRY_DEFAULTS = {
  sceneStartPair: true, // "장면이 시작되었을 때"를 꺼내면 시작 블록 묶음도 함께 꺼내기
  pairPosition: 'right', // 'right' = 오른쪽, 'below' = 아래쪽
  traceBackground: true, // 모양 그림판에 따라그리기 배경 사진 기능
  jointWarp: true, // 모양 그림판(벡터)에서 구부리기 기능
  darkMode: true, // 엔트리 전체 다크모드 (src/dark/dark-mode.js에도 같은 기본값이 있어요)
  accentColor: 'purple', // 다크모드에서 엔트리 초록 대신 쓸 색: purple | green(원래) | white | gray | navy
  blueColor: 'purple', // 다크모드에서 엔트리 UI 파랑 대신 쓸 색: purple | blue(원래) | green | white | gray | navy
  codeCollection: true, // 블록 꾸러미 맨 끝의 시그마 E 탭(편리한 코드 모음)
  storyBg: true, // 엔트리 이야기 배경을 고른 사진으로 (사진은 chrome.storage.local 'storyBgImage')
  storyBgDim: 20, // 엔트리 이야기 배경 사진을 어둡게(0~70 %)
  bgm: true, // 엔트리 페이지에서 배경음악 틀기 (음악 파일은 확장 프로그램 IndexedDB)
  bgmVolume: 50 // 배경음악 크기(0~100)
};
