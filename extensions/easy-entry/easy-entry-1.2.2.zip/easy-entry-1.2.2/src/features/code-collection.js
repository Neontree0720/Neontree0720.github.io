// 기능 6: 편리한 코드 모음 (블록 꾸러미 맨 끝의 시그마 E 탭)
// - "작품 강제 종료하기" = 엔트리의 숨은 블록 stop_run (실행하면 정지 버튼을 누른 것과 같아요)
// - "반복문 딜레이 없애기" = [ (반복 중단하기)(이)가 아니다 ] 이(가) 될 때까지 기다리기
// 작품에는 원래 엔트리 블록 그대로 저장돼요. 이지 엔트리를 쓰는 사람에게만 보라색 + 시그마 E 모양으로 보여요.
(() => {
  'use strict';

  const EE = window.__easyEntry;
  if (!EE) return;

  const CATEGORY = 'easyEntry';
  const FILL = '#7c62ff';
  const LINE = '#5b44d6';
  const SKINS = {
    forceStop: '작품 강제 종료하기',
    noDelay: '반복문 딜레이 없애기'
  };
  const PALETTE = [
    { key: 'ee_force_stop', json: { type: 'stop_run', params: [null] } },
    {
      key: 'ee_no_delay',
      json: {
        type: 'wait_until_true',
        params: [{ type: 'boolean_not', params: [null, { type: 'stop_repeat', params: [null] }, null] }, null]
      }
    }
  ];

  // ---------- 아이콘 ----------
  function sigmaPath(x0, y0, x1, y1) {
    const P = (fx, fy) => `${(x0 + fx * (x1 - x0)).toFixed(2)} ${(y0 + fy * (y1 - y0)).toFixed(2)}`;
    return `M${P(1, 0)} L${P(0, 0)} L${P(0.47, 0.5)} L${P(0.07, 1)} L${P(1, 1)} M${P(0.47, 0.5)} L${P(1, 0.5)}`;
  }

  function svgUrl(svg) {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  // 블록 오른쪽 끝의 둥근 아이콘(엔트리의 Indicator와 같은 22px)
  const INDICATOR = svgUrl(
    '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22">' +
      `<circle cx="11" cy="11" r="11" fill="${LINE}"/>` +
      `<path d="${sigmaPath(6.6, 6, 15.4, 16)}" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>` +
      '</svg>'
  );

  function categoryIcon(color) {
    return svgUrl(
      '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">' +
        `<path d="${sigmaPath(9.5, 7, 22.5, 25)}" fill="none" stroke="${color}" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>` +
        '</svg>'
    );
  }

  function injectCss() {
    if (document.getElementById('ee-code-collection-css')) return;
    const style = document.createElement('style');
    style.id = 'ee-code-collection-css';
    style.setAttribute('data-ee-dark', ''); // 다크모드가 이 스타일은 바꾸지 않게
    style.textContent = `
      #entryCategory${CATEGORY} {
        background-image: url("${categoryIcon('#7c62ff')}") !important;
        background-repeat: no-repeat !important;
        background-position: 50% 4px !important;
        background-size: 32px auto !important;
      }
      #entryCategory${CATEGORY}.entrySelectedCategory {
        background-image: url("${categoryIcon('#ffffff')}") !important;
        background-color: ${FILL} !important;
        color: #fff !important;
      }`;
    (document.head || document.documentElement).appendChild(style);
  }

  // ---------- 어떤 블록을 바꿔 보여 줄지 ----------
  function blockType(b) {
    return b && typeof b === 'object' ? b.type : null;
  }

  function skinOf(block) {
    if (!EE.settings.codeCollection || !block) return null;
    if (block.type === 'stop_run') return 'forceStop';
    if (block.type === 'wait_until_true') {
      const not = block.params && block.params[0];
      if (blockType(not) === 'boolean_not' && blockType(not.params && not.params[1]) === 'stop_repeat') return 'noDelay';
    }
    return null;
  }

  // ---------- 블록 그리기에 끼어들기 ----------
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const XLINK = 'http://www.w3.org/1999/xlink';
  let measureCtx = null;

  function textWidth(text) {
    if (!measureCtx) measureCtx = document.createElement('canvas').getContext('2d');
    measureCtx.font = "bold 12px NanumGothic, 'Nanum Gothic', sans-serif";
    return Math.ceil(measureCtx.measureText(text).width);
  }

  // 엔트리는 블록을 다시 그릴 때마다 블록 종류의 색(this._schema.color)을 다시 칠해요.
  // 그래서 바꿔 보여 줄 블록에만 보라색 색 정보를 따로 줘요(같은 종류의 다른 블록은 그대로).
  function setColors(view, on) {
    if (on && !view.__eeOrigSchema) {
      view.__eeOrigSchema = view._schema;
      view._schema = Object.assign(Object.create(view._schema), { color: FILL, outerLine: LINE, emphasizedColor: FILL });
    } else if (!on && view.__eeOrigSchema) {
      view._schema = view.__eeOrigSchema;
      view.__eeOrigSchema = null;
    } else {
      return;
    }
    if (typeof view._updateColor === 'function') view._updateColor();
  }

  function applySkin(view, skin) {
    const label = SKINS[skin];
    setColors(view, true);
    const svgGroup = view.svgGroup;
    if (!svgGroup || !view.contentSvgGroup) return;
    view.contentSvgGroup.style.display = 'none';
    let g = view.__eeSkin;
    if (!g || g.parentNode !== svgGroup) {
      g = document.createElementNS(SVG_NS, 'g');
      g.setAttribute('class', 'ee-skin');
      const text = document.createElementNS(SVG_NS, 'text');
      text.setAttribute('font-size', '12px');
      text.setAttribute('font-weight', 'bold');
      text.setAttribute('font-family', "NanumGothic, 'Nanum Gothic'");
      text.setAttribute('class', 'dragNone');
      text.setAttribute('fill', 'white');
      text.setAttribute('x', '0');
      text.setAttribute('y', '3.315');
      text.setAttribute('style', 'white-space: pre;');
      const img = document.createElementNS(SVG_NS, 'image');
      img.setAttribute('width', '22');
      img.setAttribute('height', '22');
      img.setAttribute('y', '-11');
      img.setAttributeNS(XLINK, 'xlink:href', INDICATOR);
      img.setAttribute('href', INDICATOR);
      g.appendChild(text);
      g.appendChild(img);
      // 내용 자리(contentSvgGroup) 바로 뒤에 넣어서 블록 모양 위에 보이게 해요.
      svgGroup.insertBefore(g, view.contentSvgGroup.nextSibling);
      view.__eeSkin = g;
    }
    const text = g.firstChild;
    const img = g.lastChild;
    if (text.textContent !== label) text.textContent = label;
    const tw = textWidth(label);
    const space = (window.Entry && Entry.BlockView && Entry.BlockView.PARAM_SPACE) || 5;
    img.setAttribute('transform', `translate(${tw + space},0)`);
    const cw = tw + space + 22;
    if (view.contentWidth !== cw || view.contentHeight !== 22) {
      view.set({ contentWidth: cw, contentHeight: 22 });
    }
    const pos = view.getContentPos ? view.getContentPos() : view.contentPos;
    if (pos) g.setAttribute('transform', `translate(${pos.x},${pos.y})`);
    view._render();
    if (typeof view._updateMagnet === 'function') view._updateMagnet();
    view._fillColor = FILL;
    if (view._path && !view._backgroundPath) {
      view._path.setAttribute('fill', FILL);
      view._path.setAttribute('stroke', LINE);
    }
  }

  function removeSkin(view) {
    setColors(view, false);
    if (!view.__eeSkin) return false;
    if (view.__eeSkin.parentNode) view.__eeSkin.parentNode.removeChild(view.__eeSkin);
    view.__eeSkin = null;
    if (view.contentSvgGroup) view.contentSvgGroup.style.display = '';
    return true;
  }

  function hookBlockView() {
    const BV = window.Entry && Entry.BlockView;
    if (!BV || BV.prototype.__eeHooked) return !!BV;
    const original = BV.prototype.alignContent;
    BV.prototype.alignContent = function (...args) {
      const result = original.apply(this, args);
      try {
        const skin = skinOf(this.block);
        if (skin) applySkin(this, skin);
        else if (removeSkin(this)) original.apply(this, args);
      } catch (e) {
        EE.warn('블록 모양을 바꾸지 못했어요:', e);
      }
      return result;
    };
    BV.prototype.__eeHooked = true;
    return true;
  }

  // 이미 그려져 있는 블록(보드, 블록 꾸러미)도 다시 맞춰요.
  function refreshViews(code) {
    if (!code || typeof code.getBlockList !== 'function') return;
    let list = [];
    try {
      list = code.getBlockList(false) || [];
    } catch (e) {
      return;
    }
    list.forEach((b) => {
      if (b && b.view && (skinOf(b) || b.view.__eeSkin)) {
        try {
          b.view.alignContent();
        } catch (e) {
          // 무시
        }
      }
    });
  }

  // ---------- 블록 꾸러미에 탭 넣기 ----------
  function menu() {
    const E = EE.getEntry();
    return E && E.playground && E.playground.blockMenu;
  }

  const TOUCHED_TYPES = ['stop_run', 'wait_until_true', 'boolean_not', 'stop_repeat'];

  function ourBlocks(bm) {
    const set = new Set();
    PALETTE.forEach((p) => {
      const th = bm.getThreadByBlockKey(p.key);
      const first = th && typeof th.getFirstBlock === 'function' ? th.getFirstBlock() : null;
      if (first) set.add(first);
    });
    return set;
  }

  // 엔트리는 '블록 종류' 단위로 어느 탭에 보일지 정해요(Entry.block[type].isFor).
  // 우리 탭의 블록은 원래 흐름 탭 블록과 종류가 같아서, '블록 하나하나' 단위로 나눠 보여 줘요.
  function hookSorting(bm) {
    const P = Object.getPrototypeOf(bm);
    if (!P || P.__eeSorted || typeof P._getSortedBlocks !== 'function') return;
    const original = P._getSortedBlocks;
    P._getSortedBlocks = function (...args) {
      const res = original.apply(this, args);
      try {
        const ours = ourBlocks(this);
        if (!ours.size || !Array.isArray(res)) return res;
        const [vis, hid] = res;
        if (this.lastSelector === CATEGORY && !this._selectDynamic && EE.settings.codeCollection) {
          const all = vis.concat(hid);
          return [all.filter((b) => ours.has(b)), all.filter((b) => !ours.has(b))];
        }
        return [vis.filter((b) => !ours.has(b)), hid.concat(vis.filter((b) => ours.has(b)))];
      } catch (e) {
        return res;
      }
    };
    P.__eeSorted = true;
  }

  function ensureCategory() {
    const bm = menu();
    if (!bm || !Array.isArray(bm._categoryData) || !bm._categoryCol || !bm.code) return;
    const want = !!EE.settings.codeCollection;
    const li = document.getElementById('entryCategory' + CATEGORY);
    if (!want) {
      if (li) li.remove();
      return;
    }
    if (window.Lang && Lang.Blocks && !Lang.Blocks[CATEGORY.toUpperCase()]) Lang.Blocks[CATEGORY.toUpperCase()] = '이지';
    if (!bm._categoryData.some((c) => c.category === CATEGORY)) {
      bm._categoryData.push({ category: CATEGORY, blocks: PALETTE.map((p) => p.key), visible: true });
    }
    if (!li) {
      const elem = bm._generateCategoryElement(CATEGORY, true);
      const node = elem && elem[0];
      const col = bm._categoryCol[0] || bm._categoryCol;
      if (node && col && col.appendChild) col.appendChild(node);
    }
    // 엔트리는 블록이 있는 탭만 'entryRemove'를 떼서 보여 줘요.
    const shown = document.getElementById('entryCategory' + CATEGORY);
    if (shown) shown.classList.remove('entryRemove', 'entryRemoveCategory');
    if (!Array.isArray(bm._categories) || !bm._categories.includes(CATEGORY)) {
      if (Array.isArray(bm._categories)) bm._categories.push(CATEGORY);
    }
    hookSorting(bm);
    let made = false;
    // 블록을 만들면 엔트리가 그 블록 종류의 isFor를 우리 탭으로 바꿔 버려서, 만든 뒤 원래대로 돌려놔요.
    const saved = TOUCHED_TYPES.map((t) => [t, Entry.block[t] && Entry.block[t].isFor ? Entry.block[t].isFor.slice() : undefined]);
    PALETTE.forEach((p) => {
      if (bm.getThreadByBlockKey(p.key)) return;
      const json = JSON.parse(JSON.stringify(p.json));
      json.category = CATEGORY;
      json.x = -99999;
      bm._createThread([json], undefined, p.key);
      made = true;
    });
    saved.forEach(([t, isFor]) => {
      if (Entry.block[t]) Entry.block[t].isFor = isFor;
    });
    if (made) {
      try {
        bm.code.changeEvent.notify();
      } catch (e) {
        // 무시
      }
      refreshViews(bm.code);
    }
  }

  let lastBoardCode = null;

  function tick() {
    if (!hookBlockView()) return;
    injectCss();
    try {
      ensureCategory();
    } catch (e) {
      EE.warn('이지 블록 탭을 만들지 못했어요:', e);
    }
    // 보드에 이미 있던 블록(작품을 불러온 경우)
    const E = EE.getEntry();
    const ws = E && typeof E.getMainWS === 'function' ? E.getMainWS() : null;
    const code = ws && ws.board && ws.board.code;
    if (code && code !== lastBoardCode) {
      lastBoardCode = code;
      refreshViews(code);
    }
  }

  setInterval(tick, 1000);
  tick();
  EE.registerFeature({ id: 'code-collection', onCommand() {} });
})();
