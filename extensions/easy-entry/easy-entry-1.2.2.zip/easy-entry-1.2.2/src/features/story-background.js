// 기능 7: 엔트리 이야기 배경 바꾸기 (확장 프로그램 쪽 세계에서 실행돼요)
// 엔트리 이야기(/community/entrystory) 글 목록 뒤의 회색 배경을 고른 사진으로 바꿔요.
// 사진은 이지 엔트리 설정 화면에서 고르고, chrome.storage.local 'storyBgImage'(data URL)에 저장돼요.
(() => {
  'use strict';

  if (window.top !== window) return;

  const MARK = 'ee-story-bg';
  let settings = { storyBg: true, storyBgDim: 20 };
  let image = '';
  let timer = null;

  function onStoryPage() {
    return location.pathname.indexOf('/community/entrystory') === 0;
  }

  // 글쓰기 상자(textarea)나 글 목록에서 위로 올라가며, 화면 폭만큼 넓은 배경 칸을 찾아요.
  function findArea() {
    const start = document.querySelector('textarea') || document.querySelector('ul li');
    let el = start;
    const wide = window.innerWidth * 0.9;
    while (el && el !== document.body) {
      const r = el.getBoundingClientRect();
      if (r.width >= wide && r.height > 200) return el;
      el = el.parentElement;
    }
    return null;
  }

  function styleEl() {
    let s = document.getElementById('ee-story-bg-css');
    if (!s) {
      s = document.createElement('style');
      s.id = 'ee-story-bg-css';
      s.setAttribute('data-ee-dark', ''); // 다크모드가 사진 색을 바꾸지 않게
      (document.head || document.documentElement).appendChild(s);
    }
    return s;
  }

  function clear() {
    document.querySelectorAll('.' + MARK).forEach((el) => el.classList.remove(MARK));
    const s = document.getElementById('ee-story-bg-css');
    if (s) s.textContent = '';
  }

  function apply() {
    timer = null;
    if (!settings.storyBg || !image || !onStoryPage()) {
      clear();
      return;
    }
    const area = findArea();
    if (!area) return;
    if (!area.classList.contains(MARK)) {
      document.querySelectorAll('.' + MARK).forEach((el) => el !== area && el.classList.remove(MARK));
      area.classList.add(MARK);
    }
    const dim = Math.max(0, Math.min(70, Number(settings.storyBgDim) || 0)) / 100;
    // :not(#ee-x) 는 우선순위를 높이려고 붙였어요(다크모드가 만든 규칙보다 이기게).
    const sel = `html .${MARK}:not(#ee-x)`;
    const css =
      `${sel} { background: linear-gradient(rgba(0,0,0,${dim}), rgba(0,0,0,${dim})), url("${image}") center / cover fixed no-repeat !important; }\n` +
      // 원래 배경의 엔트리봇 그림은 숨겨요.
      `${sel} > *:not(#ee-x) { background-image: none !important; }`;
    const s = styleEl();
    if (s.textContent !== css) s.textContent = css;
  }

  function schedule() {
    if (!timer) timer = setTimeout(apply, 300);
  }

  chrome.storage.sync.get({ storyBg: true, storyBgDim: 20 }, (v) => {
    settings = v;
    chrome.storage.local.get({ storyBgImage: '' }, (l) => {
      image = l.storyBgImage || '';
      schedule();
    });
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
      if (changes.storyBg) settings.storyBg = changes.storyBg.newValue;
      if (changes.storyBgDim) settings.storyBgDim = changes.storyBgDim.newValue;
    }
    if (area === 'local' && changes.storyBgImage) image = changes.storyBgImage.newValue || '';
    schedule();
  });

  // 엔트리는 페이지를 새로 불러오지 않고 화면만 바꿀 때가 많아서, 바뀔 때마다 다시 확인해요.
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
})();
