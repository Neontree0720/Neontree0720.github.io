// 기능 1: "장면이 시작되었을 때" 블록을 블록 꾸러미에서 꺼내면
// "시작하기 버튼을 클릭했을 때 → (지금 장면) 시작하기" 묶음을 바로 옆에 함께 꺼내 줍니다.
(() => {
  'use strict';

  const EE = window.__easyEntry;
  if (!EE) return;

  const TRIGGER_TYPE = 'when_scene_start';
  const HAT_TYPE = 'when_run_button_click';
  const SCENE_TYPE = 'start_scene';
  const GAP = 20; // 두 묶음 사이 간격(px)

  function getBoard() {
    const E = EE.getEntry();
    const ws = E && typeof E.getMainWS === 'function' ? E.getMainWS() : null;
    return ws && ws.board ? ws.board : null;
  }

  function findBlock(board, ref) {
    try {
      return board.findBlock(ref) || null;
    } catch (e) {
      return null;
    }
  }

  // 블록이 놓인 장면의 id. 못 찾으면 지금 선택된 장면.
  function getSceneId(board) {
    const E = EE.getEntry();
    const object = board.code && board.code.object;
    if (object && object.scene && object.scene.id) return object.scene.id;
    const selected = E && E.scene && E.scene.selectedScene;
    return selected && selected.id ? selected.id : null;
  }

  // 블록 묶음 안(조건문 등 안쪽 포함)에 "sceneId 장면 시작하기"가 있으면 true
  function threadHasSceneStart(thread, sceneId) {
    const blocks = thread && typeof thread.getBlocks === 'function' ? thread.getBlocks() : [];
    return blocks.some((b) => {
      if (!b) return false;
      if (b.type === SCENE_TYPE && b.params && b.params[0] === sceneId) return true;
      return Array.isArray(b.statements) && b.statements.some((s) => threadHasSceneStart(s, sceneId));
    });
  }

  // 작품 전체(모든 오브젝트)에 "시작하기 버튼을 클릭했을 때 → sceneId 장면 시작하기"가 이미 있으면 true
  function pairAlreadyExists(sceneId) {
    const E = EE.getEntry();
    const container = E && E.container;
    if (!container || typeof container.getAllObjects !== 'function') return false;
    return container.getAllObjects().some((object) => {
      const code = object && object.script;
      if (!code || typeof code.getThreads !== 'function') return false;
      return code.getThreads().some((thread) => {
        const first = thread && typeof thread.getFirstBlock === 'function' ? thread.getFirstBlock() : null;
        return !!first && first.type === HAT_TYPE && threadHasSceneStart(thread, sceneId);
      });
    });
  }

  function blocksAvailable() {
    const E = EE.getEntry();
    return !!(E && E.block && E.block[HAT_TYPE] && E.block[SCENE_TYPE]);
  }

  function addPairNextTo(block, board) {
    const E = EE.getEntry();
    if (!E || typeof E.do !== 'function') return;

    // 그사이 오브젝트를 바꿨거나 블록이 지워졌으면 아무것도 안 합니다.
    if (getBoard() !== board) return;
    const code = board.code;
    if (!code || typeof code.findById !== 'function' || code.findById(block.id) !== block) return;
    const thread = block.thread;
    if (!thread || typeof thread.getFirstBlock !== 'function' || thread.getFirstBlock() !== block) return;

    const view = block.view;
    if (!view || !Number.isFinite(view.x) || !Number.isFinite(view.y)) return;

    const sceneId = getSceneId(board);
    if (!sceneId || !blocksAvailable()) return;
    // 장면마다 하나만: 이 장면으로 가는 시작 묶음이 이미 있으면 만들지 않습니다.
    if (pairAlreadyExists(sceneId)) return;

    const width = Number.isFinite(view.width) ? view.width : 160;
    const height = Number.isFinite(view.height) ? view.height : 30;
    const below = EE.settings.pairPosition === 'below';
    const x = below ? view.x : view.x + width + GAP;
    const y = below ? view.y + height + GAP : view.y;

    const result = E.do('addThread', [
      { type: HAT_TYPE, params: [null], x, y },
      { type: SCENE_TYPE, params: [sceneId, null] }
    ]);

    // 방금 꺼낸 블록과 한 묶음으로 되돌리기(Ctrl+Z 한 번에 둘 다 사라짐)
    if (result && typeof result.isPass === 'function') {
      try {
        result.isPass(true);
      } catch (e) {
        // 무시: 되돌리기가 두 번 필요해질 뿐이에요.
      }
    }
  }

  EE.registerFeature({
    id: 'scene-start-pair',
    onCommand(name, args) {
      if (!EE.settings.sceneStartPair) return;
      // 블록 꾸러미에서 꺼낸 블록을 보드에 내려놓았을 때만 실행됩니다.
      // (복사/붙여넣기, 되돌리기, 휴지통에 버리기, 꾸러미로 되돌려놓기는 해당 없음)
      if (name !== 'moveBlockFromBlockMenu') return;
      if (EE.isUndoRedoInProgress()) return;

      const board = getBoard();
      if (!board) return;
      const block = findBlock(board, args[0]);
      if (!block || block.type !== TRIGGER_TYPE) return;

      // 엔트리가 드래그 처리를 마무리한 다음에 추가합니다.
      setTimeout(() => {
        try {
          addPairNextTo(block, board);
        } catch (e) {
          EE.warn('시작 블록 묶음을 만들지 못했어요:', e);
        }
      }, 0);
    }
  });
})();
