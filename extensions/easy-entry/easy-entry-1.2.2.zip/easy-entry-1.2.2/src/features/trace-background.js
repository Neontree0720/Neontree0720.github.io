// 기능 2: 따라그리기
// 모양 그림판(벡터/비트맵)에 따라 그릴 배경 사진을 깔아 줍니다.
// - 배경 사진은 그림판의 바둑판(그림 영역) 층 안, 바둑판 바로 위에 넣어서 그림 "아래"에 보여요.
//   이 층은 엔트리가 잠가 둔 층이라 엔트리 도구로는 선택/이동/지우기가 안 되고, 모양 저장·되돌리기 기록에도 들어가지 않아요.
//   (바둑판 층을 못 찾으면 캔버스 위에 반투명하게 덮는 방식으로 대신 보여 줘요.)
// - 왼쪽 도구 막대의 "사진" 도구를 고른 동안에만 배경을 옮기거나 크기를 바꿀 수 있어요.
// - 그림판 왼쪽 아래 패널: 배경 불러오기 / 투명도 / 숨기기 / 맞추기 / 삭제
(() => {
  'use strict';

  const EE = window.__easyEntry;
  const K = EE && EE.paint;
  if (!K) return;

  // 도구 아이콘 (Material Symbols "imagesmode"). 엔트리 도구 아이콘처럼 40x40으로 맞췄어요.
  const ICON_PATH =
    'M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm40-80h480L570-480 450-320l-90-120-120 160Zm-40 80v-560 560Zm182.5-377.5Q400-595 400-620t-17.5-42.5Q365-680 340-680t-42.5 17.5Q280-645 280-620t17.5 42.5Q315-560 340-560t42.5-17.5Z';

  const DEFAULT_OPACITY = 0.5;
  const MIN_SIZE = 8; // 배경 최소 크기(그림판 좌표)
  const RASTER_NAME = K.OUR_PREFIX + 'trace-background';

  // 배경 상태. 페이지를 새로고침하면 사라져요(작품에는 저장되지 않음).
  const bg = {
    src: null,
    img: null, // 다 불러온 <img>. 그림판 안에 넣을 때 씁니다.
    natW: 0,
    natH: 0,
    x: 0,
    y: 0,
    w: 0,
    h: 0,
    opacity: DEFAULT_OPACITY,
    hidden: false
  };

  let ui = null;
  let drag = null;
  let lastLayoutKey = '';
  let lastFind = 0;
  let artLayer = null; // 바둑판(그림 영역) 층
  let raster = null; // 그림판 안에 넣은 배경 (paper.js Raster)
  let rasterImg = null;
  let rasterKey = '';

  const tool = K.registerTool({
    id: 'trace',
    order: 1,
    label: '사진',
    title: '사진 - 따라그리기 배경 옮기기/크기 바꾸기 (Esc로 끝내기)',
    iconSvg: (color) =>
      '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">' +
      `<svg x="9" y="9" width="22" height="22" viewBox="0 -960 960 960" fill="${color}">` +
      `<path d="${ICON_PATH}"/></svg></svg>`,
    isEnabled: () => !!EE.settings.traceBackground,
    onActivate() {
      if (ui) ui.layer.classList.add('ee-active');
      lastLayoutKey = '';
    },
    onDeactivate() {
      endDrag();
      if (ui) ui.layer.classList.remove('ee-active');
      lastLayoutKey = '';
    }
  });

  // ---------- 그림판 안의 배경 ----------

  function getArtboardRect(p) {
    const found = K.findArtboard(p);
    if (found) return { x: found.rect.x, y: found.rect.y, w: found.rect.width, h: found.rect.height };
    const c = p.view.center;
    return { x: c.x - 480, y: c.y - 270, w: 960, h: 540 };
  }

  function removeRaster() {
    if (!raster) return;
    try {
      raster.remove();
    } catch (e) {
      // 무시
    }
    raster = null;
    rasterImg = null;
    rasterKey = '';
    const p = K.getPaint();
    if (p) K.redraw(p);
  }

  // 배경을 바둑판 층 맨 위(= 그림 바로 아래)에 넣고 위치/투명도를 맞춥니다.
  // 넣을 수 없으면 false (그때는 캔버스 위에 덮는 방식으로 보여 줘요).
  function syncRaster(p) {
    if (!bg.src || !bg.img) {
      removeRaster();
      return false;
    }
    const project = p.scope.project;
    if (!artLayer || artLayer.project !== project || !artLayer.parent) {
      removeRaster();
      return false;
    }
    // 다른 그림판 프로젝트로 바뀌었거나 새 사진을 불러왔으면 새로 만듭니다.
    if (raster && (raster.project !== project || rasterImg !== bg.img)) removeRaster();
    if (!raster) {
      raster = new p.scope.Raster({ insert: false });
      raster.name = RASTER_NAME;
      raster.image = bg.img;
      rasterImg = bg.img;
      rasterKey = '';
    }
    if (!(raster.width > 0) || !(raster.height > 0)) return false;
    if (raster.parent !== artLayer || artLayer.lastChild !== raster) {
      artLayer.addChild(raster);
      rasterKey = '';
    }
    const key = [bg.x, bg.y, bg.w, bg.h, bg.opacity, bg.hidden].join('|');
    if (key !== rasterKey) {
      rasterKey = key;
      raster.bounds = new p.scope.Rectangle(bg.x, bg.y, bg.w, bg.h);
      raster.opacity = bg.opacity;
      raster.visible = !bg.hidden;
      K.redraw(p);
    }
    return true;
  }

  // ---------- DOM ----------

  function injectStyle() {
    K.injectStyle();
    if (document.getElementById('ee-trace-style-2')) return;
    const style = document.createElement('style');
    style.id = 'ee-trace-style-2';
    style.textContent = `
      .ee-trace-layer { position: absolute; overflow: hidden; pointer-events: none; }
      .ee-trace-layer.ee-active { pointer-events: auto; cursor: default; touch-action: none; }
      .ee-trace-img { position: absolute; display: block; max-width: none; max-height: none;
        user-select: none; -webkit-user-drag: none; pointer-events: none; }
      .ee-trace-box { position: absolute; display: none; box-sizing: border-box;
        outline: 1.5px dashed #4f80ff; outline-offset: 0; cursor: move; }
      .ee-trace-layer.ee-active .ee-trace-box.ee-show { display: block; }
      .ee-trace-handle { position: absolute; width: 12px; height: 12px; margin: -6px 0 0 -6px;
        box-sizing: border-box; background: #fff; border: 2px solid #4f80ff; border-radius: 2px; }
      .ee-trace-handle[data-dir="nw"] { left: 0; top: 0; cursor: nwse-resize; }
      .ee-trace-handle[data-dir="ne"] { left: 100%; top: 0; cursor: nesw-resize; }
      .ee-trace-handle[data-dir="sw"] { left: 0; top: 100%; cursor: nesw-resize; }
      .ee-trace-handle[data-dir="se"] { left: 100%; top: 100%; cursor: nwse-resize; }
      .ee-trace-panel .ee-ctrls { display: none; align-items: center; gap: 6px; }
      .ee-trace-panel.ee-has-bg .ee-ctrls { display: flex; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function buildUI() {
    injectStyle();
    const el = K.el;

    // 사진 도구로 조작하는 층 (캔버스 바로 위)
    const layer = el('div', 'ee-trace-layer');
    const img = el('img', 'ee-trace-img', { alt: '', draggable: 'false' });
    const box = el('div', 'ee-trace-box');
    ['nw', 'ne', 'sw', 'se'].forEach((dir) => box.appendChild(el('span', 'ee-trace-handle', { 'data-dir': dir })));
    layer.appendChild(img);
    layer.appendChild(box);

    layer.addEventListener('pointerdown', onPointerDown);
    layer.addEventListener('wheel', onWheel, { passive: false });
    // 엔트리 그림판이 이 층에서 일어난 마우스/터치를 받지 않게 막습니다.
    K.stopAll(layer, ['mousedown', 'mouseup', 'click', 'dblclick', 'contextmenu', 'touchstart', 'touchmove', 'touchend']);

    // 패널
    const panel = el('div', 'ee-panel ee-trace-panel');
    const loadBtn = el('button', 'ee-primary', { type: 'button', title: '따라 그릴 사진을 배경으로 불러와요' });
    loadBtn.textContent = '배경 불러오기';
    const ctrls = el('span', 'ee-ctrls');
    const label = el('span');
    label.textContent = '배경 투명도';
    const range = el('input', '', { type: 'range', min: '0', max: '100', step: '1', title: '배경 투명도' });
    const pct = el('span', 'ee-pct');
    const toggleBtn = el('button', '', { type: 'button' });
    const fitBtn = el('button', '', { type: 'button', title: '그림 영역에 맞게 크기와 위치를 되돌려요' });
    fitBtn.textContent = '맞추기';
    const removeBtn = el('button', '', { type: 'button', title: '배경 사진을 없애요' });
    removeBtn.textContent = '삭제';
    const msg = el('span', 'ee-msg');
    const file = el('input', '', { type: 'file', accept: 'image/*' });
    file.style.display = 'none';

    ctrls.append(label, range, pct, toggleBtn, fitBtn, removeBtn);
    panel.append(loadBtn, ctrls, msg, file);
    K.isolatePanel(panel);

    loadBtn.addEventListener('click', () => {
      file.value = '';
      file.click();
    });
    file.addEventListener('change', () => {
      const f = file.files && file.files[0];
      if (f) loadFile(f);
    });
    range.addEventListener('input', () => {
      const v = Math.max(0, Math.min(100, Number(range.value) || 0));
      bg.opacity = v / 100;
      syncPanel();
    });
    toggleBtn.addEventListener('click', () => {
      bg.hidden = !bg.hidden;
      syncPanel();
    });
    fitBtn.addEventListener('click', () => {
      const p = K.getPaint();
      if (p && bg.src) fitToArtboard(p);
    });
    removeBtn.addEventListener('click', () => {
      bg.src = null;
      bg.img = null;
      bg.natW = bg.natH = 0;
      removeRaster();
      img.removeAttribute('src');
      setMessage('');
      syncPanel();
    });

    ui = { layer, img, box, panel, range, pct, toggleBtn, msg };
    if (tool.isActive()) layer.classList.add('ee-active');
    syncPanel();
  }

  function setMessage(text) {
    if (ui) ui.msg.textContent = text;
  }

  function syncPanel() {
    if (!ui) return;
    const pctValue = Math.round(bg.opacity * 100);
    ui.range.value = String(pctValue);
    ui.pct.textContent = pctValue + '%';
    ui.toggleBtn.textContent = bg.hidden ? '보이기' : '숨기기';
    ui.panel.classList.toggle('ee-has-bg', !!bg.src);
    lastLayoutKey = '';
  }

  function removeUI() {
    tool.deactivate();
    removeRaster();
    artLayer = null;
    if (!ui) return;
    ui.layer.remove();
    ui.panel.remove();
  }

  // ---------- 사진 불러오기 ----------

  function loadFile(f) {
    if (!f.type || f.type.indexOf('image/') !== 0) {
      setMessage('사진 파일만 불러올 수 있어요.');
      return;
    }
    setMessage('');
    const reader = new FileReader();
    reader.onerror = () => setMessage('파일을 읽지 못했어요.');
    reader.onload = () => {
      const src = String(reader.result || '');
      const probe = new Image();
      probe.onerror = () => setMessage('이 사진은 열 수 없어요.');
      probe.onload = () => {
        if (!probe.naturalWidth || !probe.naturalHeight) {
          setMessage('이 사진은 열 수 없어요.');
          return;
        }
        bg.src = src;
        bg.img = probe;
        bg.natW = probe.naturalWidth;
        bg.natH = probe.naturalHeight;
        bg.hidden = false;
        if (ui) ui.img.src = src;
        const p = K.getPaint();
        if (p) {
          const found = K.findArtboard(p);
          artLayer = found ? found.layer : null;
          fitToArtboard(p);
        } else {
          Object.assign(bg, { x: 0, y: 0, w: bg.natW, h: bg.natH });
        }
        syncPanel();
      };
      probe.src = src;
    };
    reader.readAsDataURL(f);
  }

  function fitToArtboard(p) {
    const a = getArtboardRect(p);
    const s = Math.min(a.w / bg.natW, a.h / bg.natH);
    bg.w = bg.natW * s;
    bg.h = bg.natH * s;
    bg.x = a.x + (a.w - bg.w) / 2;
    bg.y = a.y + (a.h - bg.h) / 2;
    lastLayoutKey = '';
  }

  // ---------- 옮기기 / 크기 바꾸기 ----------

  function onPointerDown(e) {
    if (!tool.isActive()) return;
    // 엔트리 그림판으로 가는 마우스 이벤트(그리기)를 막습니다.
    e.preventDefault();
    e.stopPropagation();
    if (e.button !== 0 || drag) return;
    const p = K.getPaint();
    if (!p || !bg.src || bg.hidden) return;

    const handle = e.target.closest && e.target.closest('.ee-trace-handle');
    const inBox = e.target.closest && e.target.closest('.ee-trace-box');
    if (!handle && !inBox) return;

    const start = K.clientToProject(p, e.clientX, e.clientY);
    const dir = handle ? handle.getAttribute('data-dir') : null;
    drag = {
      pointerId: e.pointerId,
      mode: handle ? 'resize' : 'move',
      dir,
      startX: start.x,
      startY: start.y,
      x: bg.x,
      y: bg.y,
      w: bg.w,
      h: bg.h,
      // 크기를 바꿀 때 움직이지 않는 반대쪽 꼭짓점
      ax: dir && dir.indexOf('w') >= 0 ? bg.x + bg.w : bg.x,
      ay: dir && dir.indexOf('n') >= 0 ? bg.y + bg.h : bg.y
    };
    try {
      ui.layer.setPointerCapture(e.pointerId);
    } catch (err) {
      // 무시
    }
    ui.layer.addEventListener('pointermove', onPointerMove);
    ui.layer.addEventListener('pointerup', endDrag);
    ui.layer.addEventListener('pointercancel', endDrag);
    ui.layer.addEventListener('lostpointercapture', endDrag);
  }

  function onPointerMove(e) {
    if (!drag || e.pointerId !== drag.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const p = K.getPaint();
    if (!p) return;
    const pt = K.clientToProject(p, e.clientX, e.clientY);

    if (drag.mode === 'move') {
      bg.x = drag.x + (pt.x - drag.startX);
      bg.y = drag.y + (pt.y - drag.startY);
    } else {
      const west = drag.dir.indexOf('w') >= 0;
      const north = drag.dir.indexOf('n') >= 0;
      let w = Math.max(MIN_SIZE, west ? drag.ax - pt.x : pt.x - drag.ax);
      let h = Math.max(MIN_SIZE, north ? drag.ay - pt.y : pt.y - drag.ay);
      if (!e.shiftKey) {
        // 기본은 비율 유지. Shift를 누르면 자유롭게.
        const s = Math.max(w / drag.w, h / drag.h);
        w = Math.max(MIN_SIZE, drag.w * s);
        h = Math.max(MIN_SIZE, drag.h * s);
      }
      bg.w = w;
      bg.h = h;
      bg.x = west ? drag.ax - w : drag.ax;
      bg.y = north ? drag.ay - h : drag.ay;
    }
    lastLayoutKey = '';
  }

  function endDrag() {
    if (!drag) return;
    const id = drag.pointerId;
    drag = null;
    if (!ui) return;
    ui.layer.removeEventListener('pointermove', onPointerMove);
    ui.layer.removeEventListener('pointerup', endDrag);
    ui.layer.removeEventListener('pointercancel', endDrag);
    ui.layer.removeEventListener('lostpointercapture', endDrag);
    try {
      if (ui.layer.hasPointerCapture(id)) ui.layer.releasePointerCapture(id);
    } catch (err) {
      // 무시
    }
  }

  // 사진 도구를 쓰는 중에도 마우스 휠은 그림판에 그대로 넘겨 줍니다.
  function onWheel(e) {
    if (!tool.isActive()) return;
    const p = K.getPaint();
    if (!p) return;
    e.preventDefault();
    e.stopPropagation();
    p.canvas.dispatchEvent(
      new WheelEvent('wheel', {
        bubbles: true,
        cancelable: true,
        clientX: e.clientX,
        clientY: e.clientY,
        screenX: e.screenX,
        screenY: e.screenY,
        deltaX: e.deltaX,
        deltaY: e.deltaY,
        deltaZ: e.deltaZ,
        deltaMode: e.deltaMode,
        ctrlKey: e.ctrlKey,
        shiftKey: e.shiftKey,
        altKey: e.altKey,
        metaKey: e.metaKey
      })
    );
  }

  // ---------- 화면에 배치 ----------

  function layout(p) {
    // 배경 사진은 그림판 안(그림 아래)에 그립니다. 안 되면 캔버스 위에 <img>로 덮어요.
    let inCanvas = false;
    try {
      inCanvas = syncRaster(p);
    } catch (e) {
      removeRaster();
      inCanvas = false;
    }

    K.placeOverCanvas(p, ui.layer, 1);

    const m = p.view.matrix;
    const c = p.canvas;
    const key = [
      c.offsetLeft, c.offsetTop, c.clientWidth, c.clientHeight,
      m.a, m.b, m.c, m.d, m.tx, m.ty,
      bg.src ? bg.src.length : 0, bg.x, bg.y, bg.w, bg.h, bg.opacity, bg.hidden, tool.isActive(), inCanvas
    ].join('|');
    if (key === lastLayoutKey) return;
    lastLayoutKey = key;

    const show = !!bg.src && !bg.hidden;
    ui.img.style.display = show && !inCanvas ? 'block' : 'none';
    ui.box.classList.toggle('ee-show', show);
    if (!show) return;

    const a = K.toView(p, bg.x, bg.y);
    const b = K.toView(p, bg.x + bg.w, bg.y + bg.h);
    const rect = {
      left: Math.min(a.x, b.x) + 'px',
      top: Math.min(a.y, b.y) + 'px',
      width: Math.abs(b.x - a.x) + 'px',
      height: Math.abs(b.y - a.y) + 'px'
    };
    Object.assign(ui.img.style, rect);
    Object.assign(ui.box.style, rect);
    ui.img.style.opacity = String(bg.opacity);
    if (ui.img.getAttribute('src') !== bg.src) ui.img.src = bg.src;
  }

  K.onFrame((p, now) => {
    if (!EE.settings.traceBackground) {
      if (ui && (ui.layer.isConnected || ui.panel.isConnected || raster)) removeUI();
      return;
    }
    if (!p) return;
    if (!ui) buildUI();
    const host = K.ensurePanelHost(p);
    if (ui.panel.parentElement !== host) host.appendChild(ui.panel);
    // 바둑판 층은 0.2초마다 다시 찾아요(사진이 있을 때만).
    if (now - lastFind > 200) {
      lastFind = now;
      const found = bg.src ? K.findArtboard(p) : null;
      artLayer = found ? found.layer : null;
    }
    layout(p);
  });
})();
