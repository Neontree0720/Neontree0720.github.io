// 기능 3: 구부리기 (포토샵 "퍼펫 뒤틀기"와 비슷)
// 모양 그림판(벡터)에서 "구부리기" 도구로 그림에 점을 찍고, 점 하나를 끌면 그림이 구부러져요.
// - 클릭: 점 찍기 (찍은 점은 모두 고정점)
// - 점 끌기: 끄는 점이 "잡을 점"이 되어 마우스를 따라가고, 가장 가까운 다른 점이 "관절"이 돼요.
//   고정점은 "위치만" 고정이라, 관절 자리에서 돌 수 있어요.
// - 관절→잡을 점을 팔의 뼈대로 보고, 뼈대 길이를 유지한 채 돌리고/휘게 한 뒤 팔을 굵기 그대로 다시 놓아요.
//   같은 거리에서 돌리면 관절 자리에서 돌고, 관절 쪽으로 당기면 그만큼 휘어요.
//   그림 전체에 같은 변형을 적용해서 겹쳐 있는 외곽선과 칠이 똑같이 움직여요.
// - Alt+클릭 또는 오른쪽 클릭: 점 지우기
// - 패널의 "꺾이게 ↔ 부드럽게": 꺾이게 = 팔 가운데에서 접힘, 부드럽게 = 팔 전체가 둥글게 휨.
// - 한 번 끌 때마다 엔트리 그림판 되돌리기(Ctrl+Z) 기록이 하나 남아요.
(() => {
  'use strict';

  const EE = window.__easyEntry;
  const K = EE && EE.paint;
  if (!K) return;

  const PIN_HIT = 10; // 점을 잡을 수 있는 거리(화면 px)
  const DRAG_START = 3; // 이만큼(화면 px) 움직여야 끌기로 봐요
  const MAX_SEG_LEN = 5; // 구부리기 전에 곡선을 이 길이(그림판 좌표) 이하로 잘게 나눠요
  const MAX_NEW_SEGMENTS = 40000; // 한 번에 늘어날 수 있는 점 개수 상한
  const LATERAL_RANGE = 0.45; // 팔 옆으로 이 거리(팔 길이 비율)까지는 그대로 따라오고, 두 배 거리에서 0이 돼요
  const ANCHOR_RADIUS = 0.25; // 다른 고정점이 붙잡는 범위(팔 길이 비율)
  const BEND_SAMPLES = 200; // 뼈대를 나누는 개수
  const MAX_BEND = Math.PI * 0.75; // 한 번에 휘는 최대 각도(135°). 넘으면 머리핀처럼 접혀요.
  const MIN_BEND_CAP = Math.PI * 0.3; // 굵은 도형이라도 이만큼(54°)은 휠 수 있게

  const pins = []; // { x, y } 그림판 좌표
  let pinsFor = ''; // 점을 찍은 모양(바뀌면 점을 지워요)
  let softness = 0.7; // 0 = 꺾이게, 1 = 부드럽게
  let lengthMode = 'bend'; // 잡을 점을 관절 쪽으로 당길 때: 'bend' = 길이 유지하며 휘기, 'scale' = 곧게 줄어들기(멀리 끌면 늘어나기)
  let flipBend = false; // 휘는 방향을 반대로
  let ui = null;
  let drag = null;
  let lastKey = '';
  let lastInfo = 0;

  const tool = K.registerTool({
    id: 'joint',
    order: 2,
    label: '구부리기',
    title: '구부리기 - 점을 찍고 끌어서 도형을 구부려요 (Shift+끌기: 점만 옮기기, Alt+클릭: 점 지우기, Esc로 끝내기)',
    iconSvg: (color) =>
      '<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">' +
      `<path d="M11 29 L19.5 19.5 L30 14" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<circle cx="11" cy="29" r="3.2" fill="${color}"/>` +
      `<circle cx="19.5" cy="19.5" r="3.2" fill="#fff" stroke="${color}" stroke-width="2"/>` +
      `<circle cx="30" cy="14" r="3.2" fill="${color}"/></svg>`,
    isEnabled: () => !!EE.settings.jointWarp,
    onActivate() {
      if (!ui) return;
      ui.layer.classList.add('ee-active');
      ui.panel.hidden = false;
      updateInfo();
      lastKey = '';
    },
    onDeactivate() {
      cancelDrag();
      if (!ui) return;
      ui.layer.classList.remove('ee-active');
      ui.panel.hidden = true;
      lastKey = '';
    }
  });

  // ---------- DOM ----------

  function injectStyle() {
    K.injectStyle();
    if (document.getElementById('ee-joint-style')) return;
    const style = document.createElement('style');
    style.id = 'ee-joint-style';
    style.textContent = `
      .ee-joint-layer { position: absolute; overflow: hidden; pointer-events: none; display: none; }
      .ee-joint-layer.ee-active { display: block; pointer-events: auto; cursor: crosshair; touch-action: none; }
      .ee-joint-pin { position: absolute; width: 14px; height: 14px; margin: -7px 0 0 -7px; box-sizing: border-box;
        border-radius: 50%; background: #fff; border: 2.5px solid #4f80ff; cursor: grab;
        box-shadow: 0 0 0 1.5px rgba(255,255,255,.9); }
      .ee-joint-pin.ee-joint { background: #4f80ff; }
      .ee-joint-pin.ee-grab { background: #ff9f1a; border-color: #e07b00; cursor: grabbing; }
      .ee-joint-panel .ee-soft, .ee-joint-panel .ee-seg { display: flex; align-items: center; gap: 4px; }
      .ee-joint-panel .ee-seg button { padding: 0 7px; }
      .ee-joint-panel button.ee-on { background: #4f80ff; border-color: #4f80ff; color: #fff; }
      .ee-joint-panel .ee-soft[hidden], .ee-joint-panel button[hidden] { display: none; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function buildUI() {
    injectStyle();
    const el = K.el;

    const layer = el('div', 'ee-joint-layer');
    layer.addEventListener('pointerdown', onPointerDown);
    layer.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
    });
    layer.addEventListener('wheel', onWheel, { passive: false });
    K.stopAll(layer, ['mousedown', 'mouseup', 'click', 'dblclick', 'touchstart', 'touchmove', 'touchend']);

    const panel = el('div', 'ee-panel ee-joint-panel');
    panel.hidden = true;
    const title = el('strong');
    title.textContent = '구부리기';
    const info = el('span', 'ee-muted');
    const soft = el('span', 'ee-soft');
    const sharpLabel = el('span');
    sharpLabel.textContent = '꺾이게';
    const range = el('input', '', { type: 'range', min: '0', max: '100', step: '1', title: '구부러지는 곳이 꺾이는 정도' });
    range.value = String(Math.round(softness * 100));
    const smoothLabel = el('span');
    smoothLabel.textContent = '부드럽게';
    soft.append(sharpLabel, range, smoothLabel);

    // 당기면: 휘기 / 늘이고 줄이기
    const seg = el('span', 'ee-seg');
    const segLabel = el('span');
    segLabel.textContent = '당기면';
    const bendBtn = el('button', '', { type: 'button', title: '가까운 점 쪽으로 당기면 길이를 유지하며 휘어요' });
    bendBtn.textContent = '휘기';
    const scaleBtn = el('button', '', { type: 'button', title: '휘지 않고 곧은 채로 늘어나거나 줄어들어요' });
    scaleBtn.textContent = '늘이고 줄이기';
    seg.append(segLabel, bendBtn, scaleBtn);
    const flipBtn = el('button', '', { type: 'button', title: '휘는 방향을 반대로 바꿔요 (끄는 중에 F 키)' });
    flipBtn.textContent = '방향 반대로';

    const clearBtn = el('button', '', { type: 'button', title: '찍은 점을 모두 지워요' });
    clearBtn.textContent = '점 모두 지우기';
    const msg = el('span', 'ee-msg');
    panel.append(title, info, seg, flipBtn, soft, clearBtn, msg);
    K.isolatePanel(panel);

    range.addEventListener('input', () => {
      softness = Math.max(0, Math.min(100, Number(range.value) || 0)) / 100;
    });
    bendBtn.addEventListener('click', () => {
      lengthMode = 'bend';
      syncControls();
    });
    scaleBtn.addEventListener('click', () => {
      lengthMode = 'scale';
      syncControls();
    });
    flipBtn.addEventListener('click', () => {
      flipBend = !flipBend;
      syncControls();
    });
    clearBtn.addEventListener('click', () => {
      if (drag) return;
      pins.length = 0;
      setMessage('');
      lastKey = '';
    });

    ui = { layer, panel, info, msg, pinEls: [], bendBtn, scaleBtn, flipBtn, soft };
    syncControls();
    if (tool.isActive()) {
      layer.classList.add('ee-active');
      panel.hidden = false;
    }
  }

  // 패널 버튼 상태를 맞추고, 끄는 중이면 바로 다시 계산해요.
  function syncControls() {
    if (!ui) return;
    const bending = lengthMode === 'bend';
    ui.bendBtn.classList.toggle('ee-on', bending);
    ui.scaleBtn.classList.toggle('ee-on', !bending);
    ui.flipBtn.classList.toggle('ee-on', flipBend);
    ui.flipBtn.hidden = !bending;
    ui.soft.hidden = !bending;
    reapplyDrag();
  }

  function setMessage(text) {
    if (ui) ui.msg.textContent = text;
  }

  function removeUI() {
    tool.deactivate();
    if (!ui) return;
    ui.layer.remove();
    ui.panel.remove();
  }

  // ---------- 대상(구부릴 도형) ----------

  function area(rect) {
    return Math.max(0, rect.width) * Math.max(0, rect.height);
  }

  // 엔트리에서 선택한 도형이 있으면: 그 도형 + 같은 자리에 겹쳐 있는 짝(외곽선, 칠, 하이라이트 등)만 구부려요.
  //   짝 = 선택 범위(조금 넓힌 것) 안에 들어가는 도형, 또는 선택 범위를 감싸면서 크기가 비슷한 도형.
  // 선택한 게 없으면: 그림 전체를 구부려요.
  // (선택 정보는 엔트리 그림판 store에서 읽어요. 도형의 selected 표시는 되돌리기 뒤에 틀릴 수 있어서 쓰지 않아요.)
  function getTargets(p) {
    const paint = K.findPaintLayer(p);
    if (!paint) return null;
    const kids = (paint.children || []).filter((c) => !K.isOurs(c));
    const selected = (K.getSelectedItems(p) || []).filter((c) => kids.indexOf(c) >= 0);
    if (!selected.length || selected.length >= kids.length) {
      return { items: kids, reselect: null, selectedCount: 0, pairCount: 0 };
    }
    let sel = null;
    selected.forEach((c) => {
      const b = c.bounds;
      if (b && b.width >= 0 && b.height >= 0) sel = sel ? sel.unite(b) : b.clone();
    });
    if (!sel) return { items: selected, reselect: selected, selectedCount: selected.length, pairCount: 0 };
    const margin = (r) => Math.max(3, 0.08 * Math.max(r.width, r.height));
    const selBox = sel.expand(margin(sel) * 2);
    const selArea = Math.max(1, area(sel));
    const pairs = kids.filter((c) => {
      if (selected.indexOf(c) >= 0) return false;
      const b = c.bounds;
      if (!b || !(b.width > 0 || b.height > 0)) return false;
      if (selBox.contains(b)) return true; // 선택 범위 안에 들어가는 도형
      return b.expand(margin(b) * 2).contains(sel) && area(b) <= selArea * 2.5; // 선택을 감싸는 비슷한 크기의 도형
    });
    return { items: selected.concat(pairs), reselect: selected, selectedCount: selected.length, pairCount: pairs.length };
  }

  function updateInfo() {
    if (!ui) return;
    const p = K.getPaint();
    if (!p) return;
    if (K.getMode(p) !== 'VECTOR') {
      ui.info.textContent = '벡터 모드에서만 쓸 수 있어요';
      return;
    }
    const t = getTargets(p);
    if (!t || !t.items.length) {
      ui.info.textContent = '그림이 비어 있어요';
      return;
    }
    const target = t.selectedCount
      ? `선택한 도형 ${t.selectedCount}개${t.pairCount ? ` + 겹친 짝 ${t.pairCount}개` : ''}`
      : '그림 전체 (도형을 먼저 선택하면 그것만 구부려요)';
    const how = pins.length < 2 ? '클릭: 점 찍기' : '점 끌기: 구부리기 · Shift+끌기: 점만 옮기기 · F: 방향 바꾸기';
    ui.info.textContent = `${target} · ${how}`;
  }

  // 구부릴 수 있는 Path들을 모읍니다. 사각형/원 같은 Shape는 Path로 바꿔요. 글자/그림(Raster)은 건너뜀.
  function collectPaths(item, out, skipped) {
    if (!item || K.isOurs(item)) return;
    switch (item.className) {
      case 'Path':
        out.push(item);
        break;
      case 'CompoundPath':
        (item.children || []).forEach((c) => {
          if (c.className === 'Path') out.push(c);
        });
        break;
      case 'Group':
      case 'Layer':
        (item.children || []).slice().forEach((c) => collectPaths(c, out, skipped));
        break;
      case 'Shape': {
        let path = null;
        try {
          path = item.toPath(false);
          if (path) item.replaceWith(path);
        } catch (e) {
          path = null;
        }
        if (path && path.parent) collectPaths(path, out, skipped);
        else skipped.count++;
        break;
      }
      default:
        skipped.count++;
    }
  }

  // 긴 곡선을 잘게 나눠서 구부렸을 때 매끄럽게 휘게 합니다(모양은 그대로).
  function subdivide(path, budget) {
    const curves = (path.curves || []).slice();
    curves.forEach((curve) => {
      if (budget.left <= 0) return;
      const len = curve.length;
      if (!(len > MAX_SEG_LEN)) return;
      let k = Math.min(Math.ceil(len / MAX_SEG_LEN), 64, budget.left + 1);
      if (k <= 1) return;
      budget.left -= k - 1;
      let c = curve;
      for (let j = 1; j < k && c; j++) {
        const t = 1 / (k - j + 1);
        c = typeof c.divideAtTime === 'function' ? c.divideAtTime(t) : c.divide(t, true);
      }
    });
  }

  // 각 점(앵커, 양쪽 핸들 끝)의 그림판 좌표를 저장해 둡니다.
  function captureGeometry(paths) {
    return paths.map((path) => {
      const m = path.globalMatrix;
      const a = m.a, b = m.b, c = m.c, d = m.d, tx = m.tx, ty = m.ty;
      const segs = path.segments;
      const g = new Float64Array(segs.length * 6);
      const put = (i, x, y) => {
        g[i] = a * x + c * y + tx;
        g[i + 1] = b * x + d * y + ty;
      };
      segs.forEach((s, i) => {
        const px = s.point.x, py = s.point.y;
        put(i * 6, px, py);
        put(i * 6 + 2, px + s.handleIn.x, py + s.handleIn.y);
        put(i * 6 + 4, px + s.handleOut.x, py + s.handleOut.y);
      });
      return { path, a, b, c, d, tx, ty, det: a * d - b * c, g };
    });
  }

  function applyGeometry(p, geo, warp) {
    const Point = p.scope.Point;
    geo.forEach((it) => {
      if (!it.path.parent || !(Math.abs(it.det) > 1e-12)) return;
      const toLocal = (gx, gy) => {
        const x = gx - it.tx, y = gy - it.ty;
        return [(it.d * x - it.c * y) / it.det, (-it.b * x + it.a * y) / it.det];
      };
      const segs = it.path.segments;
      const n = Math.min(segs.length, it.g.length / 6);
      for (let i = 0; i < n; i++) {
        const o = i * 6;
        const P0 = warp(it.g[o], it.g[o + 1]);
        const Pi = warp(it.g[o + 2], it.g[o + 3]);
        const Po = warp(it.g[o + 4], it.g[o + 5]);
        const pt = toLocal(P0[0], P0[1]);
        const hi = toLocal(Pi[0], Pi[1]);
        const ho = toLocal(Po[0], Po[1]);
        const s = segs[i];
        s.point = new Point(pt[0], pt[1]);
        s.handleIn = new Point(hi[0] - pt[0], hi[1] - pt[1]);
        s.handleOut = new Point(ho[0] - pt[0], ho[1] - pt[1]);
      }
    });
    K.redraw(p);
  }

  // ---------- 구부리기 계산 ----------

  function smoothstep(x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    return x * x * (3 - 2 * x);
  }

  function normalizeAngle(a) {
    while (a > Math.PI) a -= Math.PI * 2;
    while (a <= -Math.PI) a += Math.PI * 2;
    return a;
  }

  // 팔 뼈대가 어디서 얼마나 휘는지(0 → 1). 가운데(0.5)를 중심으로 soft 너비만큼 퍼져요.
  // soft가 작으면 가운데에서 확 꺾이고(팔꿈치), 크면 팔 전체에 걸쳐 둥글게 휘어요.
  function bendProfile(soft) {
    const w = Math.max(0.02, soft);
    return (x) => smoothstep((x - 0.5) / w + 0.5);
  }

  // 뼈대 방향이 각 위치에서 beta * g(x)만큼 돌 때, 길이 1짜리 뼈대 끝이 가는 곳(복소수 적분)
  function bendVector(beta, g) {
    let re = 0, im = 0;
    for (let i = 0; i < BEND_SAMPLES; i++) {
      const a = beta * g((i + 0.5) / BEND_SAMPLES);
      re += Math.cos(a);
      im += Math.sin(a);
    }
    return [re / BEND_SAMPLES, im / BEND_SAMPLES];
  }

  // 뼈대 끝까지 거리가 rho(원래 길이 대비)가 되도록 휘는 양 beta(0 이상)를 찾아요.
  function solveBend(rho, g, betaMax) {
    const mag = (b) => Math.hypot.apply(null, bendVector(b, g));
    if (mag(betaMax) >= rho) return betaMax;
    let lo = 0, hi = betaMax;
    for (let k = 0; k < 40; k++) {
      const mid = (lo + hi) / 2;
      if (mag(mid) > rho) lo = mid;
      else hi = mid;
    }
    return (lo + hi) / 2;
  }

  // 팔 구부리기 변형.
  // J: 관절(고정점), H0 → H: 잡을 점이 움직인 위치, sign: 휘는 쪽(+1/-1)
  // soft: 0 = 꺾이게(팔 가운데에서 접힘), 1 = 부드럽게(팔 전체가 둥글게 휨)
  //
  // 관절→잡을 점을 "팔"의 뼈대로 보고, 뼈대 길이는 그대로 둔 채
  // - 잡을 점이 같은 거리에서 돌면: 관절(고정점) 자리에서 팔이 돌아요.
  // - 잡을 점이 관절 쪽으로 가까워지면: 그만큼 팔이 휘어요(꺾이게/부드럽게).
  // - 팔 길이보다 멀리 끌면: 그때만 길이 방향으로 늘어나요.
  // 팔의 각 부분은 (뼈대 위치 + 옆으로 떨어진 거리)로 다시 놓아서 굵기가 유지돼요.
  // 관절 뒤쪽(몸통 쪽)은 그대로, 팔 옆으로 멀리 있는 부분(머리 등)은 점점 덜, 다른 고정점 근처는 제자리.
  // limitSide: 팔 옆으로 멀리 있는 부분을 덜 움직일지(그림 전체를 구부릴 때만 켜요)
  // allowBend: 관절 쪽으로 당길 때 휠지(true), 곧게 줄어들지(false)
  // halfWidth: 팔 굵기의 절반(모르면 0). 안쪽이 겹쳐 접히지 않을 만큼만 급하게 휘게 하는 데 써요.
  function makeWarp(J, H0, H, sign, soft, anchors, limitSide, allowBend, halfWidth) {
    if (!J) {
      const dx = H.x - H0.x, dy = H.y - H0.y;
      return (x, y) => [x + dx, y + dy];
    }
    const L = Math.hypot(H0.x - J.x, H0.y - J.y);
    if (!(L > 1e-6)) return (x, y) => [x, y];
    const ux = (H0.x - J.x) / L, uy = (H0.y - J.y) / L; // 원래 팔 방향
    const cx = H.x - J.x, cy = H.y - J.y;
    const C = Math.hypot(cx, cy);

    const g = bendProfile(soft);
    let beta = 0;
    let A = Math.max(C, 1e-6); // 뼈대 길이 (휘기: 팔 길이보다 멀리 끌 때만 바뀜 / 늘이고 줄이기: 항상 끈 거리)
    if (allowBend && C < L) {
      // 휘는 양의 한계: 최대 MAX_BEND, 그리고 굵기를 알면 안쪽이 겹치지 않을 곡률까지.
      // 한계보다 더 당기면 더 휘지 않고 그만큼 곧게 줄어들어요(접히지 않게).
      let betaMax = MAX_BEND;
      if (halfWidth > 0) {
        const w = Math.max(0.02, soft);
        const byCurvature = (w * L) / (1.5 * halfWidth * 1.1); // 가장 급한 곳의 휘는 반지름 ≥ 굵기 절반
        betaMax = Math.min(betaMax, Math.max(MIN_BEND_CAP, byCurvature));
      }
      const b = solveBend(C / L, g, betaMax);
      beta = (sign < 0 ? -1 : 1) * b;
      const m = Math.hypot.apply(null, bendVector(b, g));
      A = m > 1e-6 ? C / m : L;
    }
    const I = bendVector(beta, g);
    const chordAngle = C > 1e-9 ? Math.atan2(cy, cx) : Math.atan2(uy, ux);
    const tau = chordAngle - Math.atan2(I[1], I[0]); // 관절에서 팔이 나가는 방향

    // 뼈대를 잘게 나눠 위치/방향 표를 만들어요.
    const N = BEND_SAMPLES;
    const bx = new Float64Array(N + 1), by = new Float64Array(N + 1), ba = new Float64Array(N + 1);
    bx[0] = J.x;
    by[0] = J.y;
    ba[0] = tau;
    for (let i = 1; i <= N; i++) {
      const mid = tau + beta * g((i - 0.5) / N);
      bx[i] = bx[i - 1] + (A / N) * Math.cos(mid);
      by[i] = by[i - 1] + (A / N) * Math.sin(mid);
      ba[i] = tau + beta * g(i / N);
    }
    // 계산 오차만큼 끝을 잡을 점에 정확히 맞춰요.
    const fixX = H.x - bx[N], fixY = H.y - by[N];
    for (let i = 1; i <= N; i++) {
      bx[i] += (fixX * i) / N;
      by[i] += (fixY * i) / N;
    }
    const stretch = A / L;
    const W = LATERAL_RANGE * L;
    const r2 = Math.pow(ANCHOR_RADIUS * L, 2);
    // 관절 자리에서 돈 각도.
    // 선택한 도형을 구부릴 때(limitSide 꺼짐)는 관절 뒤쪽도 이만큼 통째로 같이 돌아요.
    // → 관절이 도형 가운데 있어도 접힌 자국이 생기지 않아요. 뒤쪽을 붙잡고 싶으면 거기에 점을 찍어요.
    // 그림 전체를 구부릴 때는 관절 뒤쪽(몸통)은 그대로 둬요.
    const jointTurn = limitSide ? 0 : normalizeAngle(tau - Math.atan2(uy, ux));

    // 옆 거리 제한 + 다른 고정점 근처는 덜 움직이게 하는 비율(0~1)
    const weightAt = (x, y, n) => {
      let w = 1;
      const an = Math.abs(n);
      if (limitSide && an > W) w = 1 - smoothstep((an - W) / W);
      for (let i = 0; i < anchors.length; i++) {
        const dx = x - anchors[i].x, dy = y - anchors[i].y;
        w *= 1 - Math.exp(-(dx * dx + dy * dy) / r2);
      }
      return w;
    };

    return (x, y) => {
      const vx = x - J.x, vy = y - J.y;
      const t = vx * ux + vy * uy; // 팔 방향 거리
      const n = -vx * uy + vy * ux; // 옆 거리
      if (t <= 0) {
        // 관절 뒤쪽: 관절을 중심으로 jointTurn만큼 돌아요(다른 고정점 근처는 덜).
        if (Math.abs(jointTurn) < 1e-9) return [x, y];
        const w = weightAt(x, y, n);
        if (w <= 1e-6) return [x, y];
        const a = jointTurn * w;
        const cs = Math.cos(a), sn = Math.sin(a);
        return [J.x + vx * cs - vy * sn, J.y + vx * sn + vy * cs];
      }
      const w = weightAt(x, y, n);
      if (w <= 1e-6) return [x, y];
      let px, py, ang;
      const f = (t / L) * N;
      if (f <= N) {
        const i0 = Math.min(N - 1, Math.floor(f));
        const fr = f - i0;
        px = bx[i0] + (bx[i0 + 1] - bx[i0]) * fr;
        py = by[i0] + (by[i0 + 1] - by[i0]) * fr;
        ang = ba[i0] + (ba[i0 + 1] - ba[i0]) * fr;
      } else {
        const ex = (t - L) * stretch;
        ang = ba[N];
        px = bx[N] + ex * Math.cos(ang);
        py = by[N] + ex * Math.sin(ang);
      }
      const X = px - n * Math.sin(ang);
      const Y = py + n * Math.cos(ang);
      return w >= 1 ? [X, Y] : [x + (X - x) * w, y + (Y - y) * w];
    };
  }

  // ---------- 마우스 ----------

  function hitPin(p, clientX, clientY) {
    const r = p.canvas.getBoundingClientRect();
    let best = -1;
    let bestD = PIN_HIT;
    pins.forEach((pin, i) => {
      const v = K.toView(p, pin.x, pin.y);
      const d = Math.hypot(r.left + v.x - clientX, r.top + v.y - clientY);
      if (d <= bestD) {
        best = i;
        bestD = d;
      }
    });
    return best;
  }

  function onPointerDown(e) {
    if (!tool.isActive()) return;
    e.preventDefault();
    e.stopPropagation();
    if (drag) return;
    const p = K.getPaint();
    if (!p) return;
    if (K.getMode(p) !== 'VECTOR') {
      setMessage('구부리기는 벡터 모드에서만 돼요.');
      return;
    }
    setMessage('');
    const hit = hitPin(p, e.clientX, e.clientY);

    // 점 지우기: 오른쪽 클릭 또는 Alt+클릭
    if (e.button === 2 || (e.button === 0 && e.altKey)) {
      if (hit >= 0) {
        pins.splice(hit, 1);
        lastKey = '';
      }
      return;
    }
    if (e.button !== 0) return;

    // 빈 곳 클릭: 점 찍기
    if (hit < 0) {
      const pt = K.clientToProject(p, e.clientX, e.clientY);
      pins.push({ x: pt.x, y: pt.y });
      lastKey = '';
      return;
    }

    // 점 끌기 시작 (Shift를 누르고 끌면 그림은 그대로 두고 점만 옮겨요)
    drag = {
      pointerId: e.pointerId,
      index: hit,
      pinOnly: !!e.shiftKey,
      startX: e.clientX,
      startY: e.clientY,
      H0: { x: pins[hit].x, y: pins[hit].y },
      H: { x: pins[hit].x, y: pins[hit].y },
      J: null, // 관절 = 잡을 점과 가장 가까운 다른 점
      anchors: [], // 나머지 고정점
      theta: 0,
      sign: 0, // 팔이 휘는 쪽. 처음 돌린 방향으로 정하고 끌기 동안 유지해요(갑자기 반대로 튀지 않게)
      moved: false,
      geo: null,
      reselect: null
    };
    try {
      ui.layer.setPointerCapture(e.pointerId);
    } catch (err) {
      // 무시
    }
    ui.layer.addEventListener('pointermove', onPointerMove);
    ui.layer.addEventListener('pointerup', onPointerUp);
    ui.layer.addEventListener('pointercancel', cancelDrag);
    lastKey = '';
  }

  // 처음 실제로 끌 때 한 번: 대상 모으기, 곡선 잘게 나누기, 원래 모양 저장
  function prepare(p) {
    const t = getTargets(p);
    if (!t || !t.items.length) {
      setMessage('구부릴 그림이 없어요.');
      return false;
    }
    const paths = [];
    const skipped = { count: 0 };
    t.items.slice().forEach((item) => collectPaths(item, paths, skipped));
    if (!paths.length) {
      setMessage('구부릴 수 있는 도형이 없어요. (글자·사진은 안 돼요)');
      return false;
    }
    // 엔트리 편집 안내선(선택 상자, 형태 도구 점)이 옛 모양으로 남지 않게 지워 둡니다.
    K.clearGuides(p);
    const budget = { left: MAX_NEW_SEGMENTS };
    paths.forEach((path) => subdivide(path, budget));
    drag.geo = captureGeometry(paths);
    drag.reselect = t.reselect;
    drag.limitSide = !t.selectedCount;

    // 관절 = 잡을 점과 가장 가까운 다른 점. 나머지 점은 제자리를 지켜요.
    const others = pins.filter((_, i) => i !== drag.index).map((pin) => ({ x: pin.x, y: pin.y }));
    let J = null;
    let bestD = Infinity;
    others.forEach((o) => {
      const d = Math.hypot(o.x - drag.H0.x, o.y - drag.H0.y);
      if (d < bestD) {
        bestD = d;
        J = o;
      }
    });
    drag.J = J;
    drag.jointIndex = J ? pins.findIndex((pin, i) => i !== drag.index && pin.x === J.x && pin.y === J.y) : -1;
    drag.anchors = others.filter((o) => o !== J);
    drag.halfWidth = J && !drag.limitSide ? measureHalfWidth(drag.geo, J, drag.H0) : 0;
    if (skipped.count) setMessage(`글자·사진 ${skipped.count}개는 구부리지 않아요.`);
    return true;
  }

  // 관절→잡을 점 사이에 있는 점들이 뼈대에서 옆으로 얼마나 떨어져 있는지(90% 지점) = 팔 굵기의 절반.
  // 선택한 도형을 구부릴 때만 써요(그림 전체면 몸통까지 섞여서 의미가 없어요).
  function measureHalfWidth(geo, J, H0) {
    const L = Math.hypot(H0.x - J.x, H0.y - J.y);
    if (!(L > 1e-6)) return 0;
    const ux = (H0.x - J.x) / L, uy = (H0.y - J.y) / L;
    const sides = [];
    geo.forEach((it) => {
      for (let o = 0; o < it.g.length; o += 6) {
        const vx = it.g[o] - J.x, vy = it.g[o + 1] - J.y;
        const t = vx * ux + vy * uy;
        if (t > 0 && t < L) sides.push(Math.abs(-vx * uy + vy * ux));
      }
    });
    if (!sides.length) return 0;
    sides.sort((a, b) => a - b);
    return sides[Math.min(sides.length - 1, Math.floor(sides.length * 0.9))];
  }

  function onPointerMove(e) {
    if (!drag || e.pointerId !== drag.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const p = K.getPaint();
    if (!p) return;
    if (drag.pinOnly) {
      if (!drag.moved && Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) < DRAG_START) return;
      drag.moved = true;
      const pt = K.clientToProject(p, e.clientX, e.clientY);
      drag.H = { x: pt.x, y: pt.y };
      lastKey = '';
      return;
    }
    if (!drag.moved) {
      if (Math.hypot(e.clientX - drag.startX, e.clientY - drag.startY) < DRAG_START) return;
      drag.moved = true;
      let ok = false;
      try {
        ok = prepare(p);
      } catch (err) {
        EE.warn('구부리기 준비 중 오류:', err);
        ok = false;
      }
      if (!ok) {
        endDrag();
        return;
      }
    }
    const H = K.clientToProject(p, e.clientX, e.clientY);
    drag.H = { x: H.x, y: H.y };
    if (drag.J) {
      const raw = Math.atan2(H.y - drag.J.y, H.x - drag.J.x) - Math.atan2(drag.H0.y - drag.J.y, drag.H0.x - drag.J.x);
      drag.theta += normalizeAngle(raw - drag.theta);
      if (!drag.sign && Math.abs(drag.theta) > 0.03) drag.sign = drag.theta > 0 ? 1 : -1;
    }
    applyDragWarp(p);
  }

  // 지금 끌고 있는 위치로 다시 구부려요(방향/모드를 바꿨을 때도 씀).
  function applyDragWarp(p) {
    const sign = (drag.sign || 1) * (flipBend ? -1 : 1);
    const warp = makeWarp(drag.J, drag.H0, drag.H, sign, softness, drag.anchors, drag.limitSide, lengthMode === 'bend', drag.halfWidth || 0);
    applyGeometry(p, drag.geo, warp);
    lastKey = '';
  }

  function reapplyDrag() {
    if (!drag || drag.pinOnly || !drag.moved || !drag.geo) return;
    const p = K.getPaint();
    if (p) applyDragWarp(p);
  }

  // F 키: 휘는 방향 바꾸기 (구부리기 도구를 쓰는 중에만)
  document.addEventListener(
    'keydown',
    (e) => {
      if (!tool.isActive() || e.code !== 'KeyF' || e.repeat || e.ctrlKey || e.metaKey || e.altKey) return;
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
      e.preventDefault();
      e.stopPropagation();
      flipBend = !flipBend;
      syncControls();
    },
    true
  );

  function onPointerUp(e) {
    if (!drag || e.pointerId !== drag.pointerId) return;
    e.preventDefault();
    e.stopPropagation();
    const d = drag;
    endDrag();
    if (d.pinOnly) {
      // 점만 옮기기: 그림은 그대로, 기록도 남기지 않아요.
      if (d.moved && pins[d.index]) {
        pins[d.index].x = d.H.x;
        pins[d.index].y = d.H.y;
      }
      lastKey = '';
      return;
    }
    if (!d.moved || !d.geo) return;
    if (pins[d.index]) {
      pins[d.index].x = d.H.x;
      pins[d.index].y = d.H.y;
    }
    const p = K.getPaint();
    if (!p) return;
    // 엔트리 되돌리기 기록 남기기
    const ok = K.saveSnapshot(p, d.reselect);
    if (!ok) setMessage('되돌리기 기록을 남기지 못했어요. (모양 저장은 돼요)');
    updateInfo();
    lastKey = '';
  }

  // 끌기를 취소하면 원래 모양으로 돌려놓습니다.
  function cancelDrag() {
    if (!drag) return;
    const d = drag;
    endDrag();
    if (d.moved && d.geo) {
      const p = K.getPaint();
      if (p) applyGeometry(p, d.geo, (x, y) => [x, y]);
    }
  }

  function endDrag() {
    if (!drag) return;
    const id = drag.pointerId;
    drag = null;
    lastKey = '';
    if (!ui) return;
    ui.layer.removeEventListener('pointermove', onPointerMove);
    ui.layer.removeEventListener('pointerup', onPointerUp);
    ui.layer.removeEventListener('pointercancel', cancelDrag);
    try {
      if (ui.layer.hasPointerCapture(id)) ui.layer.releasePointerCapture(id);
    } catch (err) {
      // 무시
    }
  }

  // 구부리기 도구를 쓰는 중에도 마우스 휠은 그림판에 그대로 넘겨 줍니다.
  function onWheel(e) {
    if (!tool.isActive()) return;
    const p = K.getPaint();
    if (!p) return;
    e.preventDefault();
    e.stopPropagation();
    p.canvas.dispatchEvent(
      new WheelEvent('wheel', {
        bubbles: true,
        cancelable: true,
        clientX: e.clientX,
        clientY: e.clientY,
        deltaX: e.deltaX,
        deltaY: e.deltaY,
        deltaZ: e.deltaZ,
        deltaMode: e.deltaMode,
        ctrlKey: e.ctrlKey,
        shiftKey: e.shiftKey,
        altKey: e.altKey,
        metaKey: e.metaKey
      })
    );
  }

  // ---------- 점 그리기 ----------

  function layoutPins(p) {
    const m = p.view.matrix;
    const c = p.canvas;
    const key = [
      c.offsetLeft, c.offsetTop, c.clientWidth, c.clientHeight, m.a, m.b, m.c, m.d, m.tx, m.ty,
      tool.isActive(), JSON.stringify(pins), drag ? [drag.index, drag.H.x, drag.H.y, drag.jointIndex].join(',') : ''
    ].join('|');
    if (key === lastKey) return;
    lastKey = key;

    while (ui.pinEls.length < pins.length) {
      const dot = K.el('span', 'ee-joint-pin');
      ui.layer.appendChild(dot);
      ui.pinEls.push(dot);
    }
    while (ui.pinEls.length > pins.length) ui.pinEls.pop().remove();

    pins.forEach((pin, i) => {
      const dragging = drag && drag.index === i;
      const pos = dragging ? drag.H : pin;
      const v = K.toView(p, pos.x, pos.y);
      const dot = ui.pinEls[i];
      dot.style.left = v.x + 'px';
      dot.style.top = v.y + 'px';
      dot.classList.toggle('ee-grab', !!dragging);
      dot.classList.toggle('ee-joint', !!(drag && drag.jointIndex === i));
    });
  }

  function fileKey(p) {
    const f = p.painter && p.painter.file;
    return f ? String(f.id || '') + ':' + String(f.objectId || '') : '';
  }

  K.onFrame((p, now) => {
    if (!EE.settings.jointWarp) {
      if (ui && (ui.layer.isConnected || ui.panel.isConnected)) removeUI();
      return;
    }
    if (!p) return;
    if (!ui) buildUI();

    // 다른 모양으로 바뀌면 점을 지워요.
    const key = fileKey(p);
    if (key !== pinsFor) {
      pinsFor = key;
      if (!drag) {
        pins.length = 0;
        lastKey = '';
      }
    }

    const host = K.ensurePanelHost(p);
    if (ui.panel.parentElement !== host) host.insertBefore(ui.panel, host.firstChild);
    K.placeOverCanvas(p, ui.layer, 2);
    if (tool.isActive() && now - lastInfo > 400) {
      lastInfo = now;
      updateInfo();
    }
    layoutPins(p);
  });
})();
